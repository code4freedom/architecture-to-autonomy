# Whetstone

Practice exams for AI certifications. A single self-contained HTML file with no
external requests, no build-time network access, and no tracking.

Live app: `whetstone.html`

Made for practice and exam preparation. Original items written from published exam
guides. Not affiliated with any certification body, and no real exam content.

## What is covered

| Exam | Code | Status |
| --- | --- | --- |
| Claude Certified Architect – Foundations | CCAR-F | 151 items, 10 tests, 34 rules |
| Claude Certified Associate – Foundations | CCAO-F | Unwritten |
| Claude Certified Developer – Foundations | CCDV-F | Unwritten |
| Claude Certified Architect – Professional | CCAR-P | Unwritten |

## Build

```
npm install jsdom          # for the test suite only
node build.js              # writes whetstone.html
node final.js              # 30-point check on the built file
```

`build.js` assembles the shell, item banks, engine, palette and brand assets into
one file, then asserts that every required style and element survived. It exits
non-zero if any patch failed to match, which is the guard against silent no-op
string replacements.

## Files

| File | Purpose |
| --- | --- |
| `shell.html` | Unbuilt HTML skeleton: markup and base stylesheet |
| `engine2.js` | Exam engine: forms, drills, scoring, history, rendering |
| `upgrade-data.js` | Principle library, task-statement titles, item mapping |
| `batchA.js` – `batchD.js` | Item bank source, 45 + 45 items over the original 61 |
| `build.js` | Assembles and verifies the output |
| `final.js` | Content, style, scoring, accessibility and robustness checks |
| `whetstone-mark.svg` | Logo mark, also inlined as the favicon |
| `whetstone-card.svg/.png` | 1200x630 card, inlined as the landing header |

## Adding an exam

`PROGRAMMES` in `engine2.js` is a list of vendor groups, each holding its own
exams and footnote. Set `live: true` and point the track at an item bank. Cards
sort so that written exams float to the top of their group.

## Item bank design

Every item carries a domain, a task statement, a principle, and for contrast
pairs a note explaining what flips the answer. The build fails if an item's task
statement does not match its domain, or if a principle has no items.

Forms are composed to the published blueprint weights (16/11/12/12/9 for CCAR-F)
and built by tracking how often each item has been used, so repetition stays even.
Options are shuffled per sitting, and letter references inside explanations are
remapped at render time to match.

## Known defect

The correct option is the longest option in 62% of single-answer items, against
25% by chance. A test-wise candidate could beat the pass mark by always picking
the longest answer. Fixing this means editing keys down to the same grain as their
distractors across roughly 90 items. It is the one significant piece of
outstanding work.

## Scoring

Scaled to 100–1,000 with a 720 cut, weighted by blueprint domain weight rather
than raw item count, so a weak high-weight domain costs what it would on the real
exam. Results and missed items are stored in the browser only.
