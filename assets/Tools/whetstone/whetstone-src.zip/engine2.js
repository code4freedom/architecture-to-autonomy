<script>
/* ---------- state ---------- */
let MODE = "exam";
let LABEL = "";
let ORDER = [], ANSWERS = [], FLAGS = [], CHECKED = [], UNSURE = [], PERM = [];
let CUR = 0, TIMER_ID = null, SECONDS_LEFT = 0, TOTAL_SECONDS = 0;
let SPENT = [], ENTERED = 0, STREAK = 0, BEST_STREAK = 0;
let FILTER = "all";
let RULES_RETURN = "screen-start";
const LETTERS = ["A","B","C","D","E"];
const $ = id => document.getElementById(id);

/* ---------- history across sittings (best effort; silent if storage is blocked) ---------- */
const HKEY = "ccarf-history-v1";
let HIST = {};
function loadHist(){ try{ HIST = JSON.parse(localStorage.getItem(HKEY) || "{}"); }catch(e){ HIST = {}; } }
function saveHist(){ try{ localStorage.setItem(HKEY, JSON.stringify(HIST)); }catch(e){} }
function histFor(id){ return HIST[id] || {seen:0, missed:0}; }
function missedBefore(){ return ITEMS.filter(it=>histFor(it.id).missed > 0); }
function resetHist(){
  if(!confirm("Clear the record of which items you have missed before?")) return;
  HIST = {}; saveHist(); refreshHistUI();
}
function refreshHistUI(){
  const m = missedBefore();
  const btn = $("btn-hist-drill"), note = $("hist-note");
  if(!btn) return;
  btn.disabled = m.length === 0;
  btn.textContent = m.length ? "Drill the " + m.length + " items I have missed before"
                             : "No missed items on record yet";
  const total = Object.keys(HIST).length;
  note.textContent = total ? total + " items attempted across previous sittings on this browser." : "";
}
function drillHistory(){
  const m = missedBefore();
  if(m.length) launch("drill", m, 0, "Drill · missed in earlier sittings");
}
loadHist();

/* ---------- 10 fixed forms, each blueprint-composed ---------- */
const FORM_COUNT = 10;
const FORM_NEED = {1:16, 2:11, 3:12, 4:12, 5:9};
const FKEY = "ccarf-forms-v1";
let FORMS = {};
function loadForms(){ try{ FORMS = JSON.parse(localStorage.getItem(FKEY) || "{}"); }catch(e){ FORMS = {}; } }
function saveForms(){ try{ localStorage.setItem(FKEY, JSON.stringify(FORMS)); }catch(e){} }
loadForms();

function mulberry32(a){
  return function(){
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

/* Build all forms once, balancing how often each item is used.
   The bank is smaller than 10 x 60, so items necessarily repeat; this keeps
   the repetition even and the overlap between any two tests as low as the
   pool size allows. */
let FORM_CACHE = null;
function buildAllForms(){
  if(FORM_CACHE) return FORM_CACHE;
  const used = {};
  ITEMS.forEach(it=>{ used[it.id] = 0; });
  FORM_CACHE = [];
  for(let n = 1; n <= FORM_COUNT; n++){
    const rnd = mulberry32(n * 2654435761);
    const jitter = {};
    ITEMS.forEach(it=>{ jitter[it.id] = rnd(); });
    const picked = [];
    Object.keys(FORM_NEED).forEach(d=>{
      const pool = ITEMS.filter(it=>it.d === +d).slice();
      // least-used first, ties broken deterministically per form
      pool.sort((a,b)=> (used[a.id] - used[b.id]) || (jitter[a.id] - jitter[b.id]));
      pool.slice(0, FORM_NEED[d]).forEach(it=>{ picked.push(it); used[it.id]++; });
    });
    picked.sort((a,b)=> a.s - b.s || a.id.localeCompare(b.id));
    FORM_CACHE.push(picked);
  }
  return FORM_CACHE;
}
function buildForm(n){ return buildAllForms()[n-1].slice(); }

function startForm(n){
  CURRENT_FORM = n;
  launch("exam", buildForm(n), 120, "Practice test " + n + " of " + FORM_COUNT);
}
let CURRENT_FORM = null;

/* ---------- custom-length sittings ---------- */
const CKEY = "ccarf-custom-offset-v1";
function loadOffset(){ try{ return parseInt(localStorage.getItem(CKEY) || "0", 10) || 0; }catch(e){ return 0; } }
function saveOffset(v){ try{ localStorage.setItem(CKEY, String(v)); }catch(e){} }

/* split n items across domains by blueprint weight, largest remainder, capped at pool size */
function allocate(n){
  const pools = {}; Object.keys(DOMAINS).forEach(d=>{ pools[d] = ITEMS.filter(it=>it.d === +d).length; });
  const alloc = {}, rem = [];
  let sum = 0, wTotal = 0;
  Object.keys(DOMAINS).forEach(d=>{ wTotal += DOMAINS[d].weight; });
  Object.keys(DOMAINS).forEach(d=>{
    const exact = n * DOMAINS[d].weight / wTotal;
    alloc[d] = Math.min(Math.floor(exact), pools[d]);
    sum += alloc[d];
    rem.push([d, exact - Math.floor(exact)]);
  });
  rem.sort((a,b)=> b[1] - a[1]);
  // distribute the leftover slots round-robin in remainder order, not all onto one domain
  let guard = 0, i = 0;
  while(sum < n && guard++ < 1000){
    if(rem.every(([d])=>alloc[d] >= pools[d])) break;
    const d = rem[i++ % rem.length][0];
    if(alloc[d] < pools[d]){ alloc[d]++; sum++; }
  }
  return alloc;
}

function buildCustom(n){
  const alloc = allocate(n);
  const off = loadOffset();
  const picked = [];
  Object.keys(alloc).forEach(d=>{
    const pool = ITEMS.filter(it=>it.d === +d);
    const need = alloc[d];
    const start = pool.length ? (off * need) % pool.length : 0;
    for(let k=0; k<need; k++) picked.push(pool[(start + k) % pool.length]);
  });
  saveOffset(off + 1);
  return picked.sort((a,b)=> a.s - b.s || a.id.localeCompare(b.id));
}

function startCustom(){
  const input = $("custom-n");
  let n = parseInt(input.value, 10);
  const max = ITEMS.length;
  if(isNaN(n)) n = 20;
  n = Math.max(5, Math.min(max, n));
  input.value = n;
  const untimed = $("custom-untimed").checked;
  const items = buildCustom(n);
  const mins = untimed ? 0 : Math.max(1, Math.round(n * 2));
  launch(untimed ? "drill" : "exam", items, mins,
    "Custom · " + items.length + " items · " + (untimed ? "untimed, answers shown" : mins + " min"));
}
function setCustom(n){ $("custom-n").value = n; startCustom(); }

function renderMastery(){
  const host = $("mastery");
  if(!host) return;
  let unseen = 0, clean = 0, shaky = 0;
  const cells = ITEMS.map(it=>{
    const h = HIST[it.id];
    let cls = "mc-unseen", label = "not yet seen";
    if(!h){ unseen++; }
    else if(h.missed > 0){ cls = "mc-missed"; shaky++; label = "missed " + h.missed + " of " + h.seen; }
    else { cls = "mc-clean"; clean++; label = "correct on " + h.seen; }
    return '<i class="' + cls + '" title="Domain ' + it.d + ' · Task ' + it.ts + ' · ' + label + '"></i>';
  }).join("");
  host.innerHTML = '<div class="mastery-grid">' + cells + '</div>' +
    '<div class="mastery-key">' +
    '<span><i class="mc-clean"></i> ' + clean + ' always correct</span>' +
    '<span><i class="mc-missed"></i> ' + shaky + ' missed at least once</span>' +
    '<span><i class="mc-unseen"></i> ' + unseen + ' not yet seen</span>' +
    '<span id="streak-note"></span></div>';
}

function formOverlapNote(){
  const forms = buildAllForms().map(f=>f.map(i=>i.id));
  let tot = 0, pairs = 0;
  for(let a=0; a<forms.length; a++){
    for(let b=a+1; b<forms.length; b++){
      const A = new Set(forms[a]);
      tot += forms[b].filter(x=>A.has(x)).length; pairs++;
    }
  }
  const mean = Math.round(tot/pairs);
  const seen = new Set();
  let exhausted = forms.length;
  for(let i=0; i<forms.length; i++){
    forms[i].forEach(x=>seen.add(x));
    if(seen.size === ITEMS.length){ exhausted = i+1; break; }
  }
  const el = $("form-note");
  if(!el) return;
  el.textContent = "The bank holds " + ITEMS.length + " items, so the ten tests draw on the same pool rather than " +
    (FORM_COUNT * 60) + " separate questions. Any two tests share about " + mean +
    " of their 60 items, and you will have seen every item in the bank by test " + exhausted +
    ". Later tests recombine and reshuffle rather than introduce anything new.";
}

function renderForms(){
  const host = $("form-grid");
  if(!host) return;
  host.innerHTML = "";
  for(let n=1; n<=FORM_COUNT; n++){
    const rec = FORMS["f"+n];
    const badge = rec ? '<span class="form-score '+(rec.scaled>=720?"pass":"fail")+'">'+rec.scaled+'</span>'
                      : '<span class="form-score none">not taken</span>';
    host.innerHTML += '<button class="form-card" onclick="startForm('+n+')">'+
      '<span class="form-n">Test '+n+'</span>'+badge+
      '<span class="form-sub">60 items · 120 min</span></button>';
  }
}

/* ---------- exam catalogue ----------
   Adding a track later is a config entry plus its own item bank: set live:true
   and point `bank` at the items for that exam. --------------------------------- */
const PROGRAMMES = [
  {
    vendor:"Anthropic", programme:"Claude certifications",
    footnote:"All four are proctored through Pearson VUE, scored to 720 on a 100 to 1,000 scale, and valid for 12 months. Codes and audiences come from the Anthropic Partner Academy certification pages, checked July 2026.",
    exams:[
      {code:"CCAO-F", name:"Claude Certified Associate \u2013 Foundations", live:false,
       who:"Client-facing roles. Consultants, sellers and delivery leads guiding customers toward the right Claude use cases. Does not count toward partner tier."},
      {code:"CCDV-F", name:"Claude Certified Developer \u2013 Foundations", live:false,
       who:"Engineers shipping Claude-powered applications and agents with the API, Claude Code and MCP."},
      {code:"CCAR-F", name:"Claude Certified Architect \u2013 Foundations", live:true,
       who:"Solution architects designing production Claude systems end to end, with six months or more of hands-on experience."},
      {code:"CCAR-P", name:"Claude Certified Architect \u2013 Professional", live:false,
       who:"The advanced architect tier, sitting above Foundations."}
    ]
  }
];
const EXAMS = PROGRAMMES.flatMap(p=>p.exams);

function renderExams(){
  const host = $("exam-grid");
  if(!host) return;
  host.innerHTML = PROGRAMMES.map(prog=>{
    // whatever is written floats to the top; declaration order holds within each state
    const ordered = prog.exams.slice().sort((a,b)=> (b.live?1:0) - (a.live?1:0));
    const ready = prog.exams.filter(x=>x.live).length;
    return '<section class="prog">' +
      '<div class="prog-head">' +
        '<span class="prog-label">' + prog.vendor + ' \u00b7 ' + prog.programme + '</span>' +
        '<span class="prog-rule"></span>' +
        '<span class="prog-count">' + ready + ' of ' + prog.exams.length + ' ready</span>' +
      '</div>' +
      '<div class="prog-grid">' + ordered.map(x=>renderExamCard(x, EXAMS.indexOf(x))).join("") + '</div>' +
      (prog.footnote ? '<p class="prog-note">' + prog.footnote + '</p>' : "") +
    '</section>';
  }).join("");
}

function renderExamCard(x, i){
  const live = x.live;
  const badge = live
    ? '<span class="exam-badge free">Free</span>'
    : '<span class="exam-badge soon">Coming soon</span>';
  const meta = live
    ? '<span class="exam-meta">' + ITEMS.length + ' items \u00b7 ' + FORM_COUNT + ' tests \u00b7 ' +
      Object.keys(PRINCIPLES).length + ' rules</span>' +
      '<span class="exam-meta">720 to pass \u00b7 exam guide v1.0</span>' +
      '<span class="exam-cta">Start practising \u2192</span>'
    : '<span class="exam-meta">No items yet</span>';
  return '<button class="exam-card ' + (live ? "live" : "soon") + '"' +
    (live ? ' onclick="openExam(' + i + ')"' : ' disabled aria-disabled="true"') + '>' +
    '<span class="exam-top"><span class="exam-code">' + x.code + '</span>' + badge + '</span>' +
    '<span class="exam-name">' + x.name + '</span>' +
    '<span class="exam-who">' + x.who + '</span>' +
    '<span class="exam-status">' + meta + '</span></button>';
}

function openExam(i){
  if(!EXAMS[i] || !EXAMS[i].live) return;
  $("screen-home").classList.add("hidden");
  $("screen-start").classList.remove("hidden");
  window.scrollTo({top:0, behavior:"instant"});
}

function goHome(){
  ["screen-start","screen-exam","screen-results","screen-rules"].forEach(x=>$(x).classList.add("hidden"));
  if(TIMER_ID) clearInterval(TIMER_ID);
  $("screen-home").classList.remove("hidden");
  renderExams();
  window.scrollTo({top:0, behavior:"instant"});
}

/* ---------- start screen ---------- */
(function initStart(){
  const gc = document.getElementById("guide-count");
  if(gc) gc.textContent = guideItems().length;

  $("dom-composition").innerHTML = Object.keys(DOMAINS).map(k=>{
    const d = DOMAINS[k];
    return '<div class="domrow"><span class="bar" style="width:'+(d.weight*3.2)+'px"></span>'+
           '<span class="lbl">'+d.weight+'% &nbsp;'+d.name+'</span></div>';
  }).join("");
  const n = ITEMS.length;
  const setTxt = (id, txt) => { const el = $(id); if(el) el.textContent = txt; };
  setTxt("m-exam-body", "All " + n + " items in one sitting, " + Math.round(n*2) + " minutes. No feedback until you submit.");
  setTxt("m-sim-body", "60 items drawn from 4 of the 6 scenarios, 120 minutes. Closest to the real exam's structure.");
  setTxt("m-study-body", "All " + n + " items, with an answer check and explanation after each one.");
  setTxt("rules-count", Object.keys(PRINCIPLES).length + " rules and the trap each one is built around, grouped by domain.");
  refreshHistUI();
  renderForms();
  formOverlapNote();
  renderMastery();
  renderExams();
  $("drill-domains").innerHTML = Object.keys(DOMAINS).map(k=>
    '<button class="filter-btn" onclick="drillDomain('+k+')">Domain '+k+' · '+DOMAINS[k].name+'</button>'
  ).join("");
})();

function shuffle(a){ for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return a; }

/* ---------- launching ---------- */
function startMode(mode){
  if(mode === "sim"){
    // the real exam is 60 items drawn from 4 of the 6 scenarios
    const ids = shuffle([1,2,3,4,5,6]).slice(0,4);
    const pool = ITEMS.filter(it=>ids.indexOf(it.s) >= 0);
    const alloc = allocate(60), picked = [];
    Object.keys(alloc).forEach(d=>{
      const dp = shuffle(pool.filter(it=>it.d === +d));
      for(let k=0; k<alloc[d] && k<dp.length; k++) picked.push(dp[k]);
    });
    // top up from the same scenarios if a domain ran short inside them
    if(picked.length < 60){
      shuffle(pool.filter(it=>picked.indexOf(it) < 0)).slice(0, 60 - picked.length).forEach(it=>picked.push(it));
    }
    picked.sort((a,b)=> a.s - b.s || a.id.localeCompare(b.id));
    launch("exam", picked, 120, "Simulation · " + picked.length + " items from scenarios " + ids.sort().join(", "));
    return;
  }
  const items = ITEMS.slice();
  const mins = mode === "exam" ? Math.round(items.length * 2) : 0;
  launch(mode, items, mins,
    mode === "exam" ? "Whole bank · " + items.length + " items" : "Study · " + items.length + " items");
}

function guideItems(){ return ITEMS.filter(it=>it.src === "guide"); }

function drillGuide(){
  const items = guideItems();
  if(!items.length) return;
  launch("drill", items, 0, "Official exam guide \u00b7 section 9 samples");
}

function drillDomain(d){
  const items = ITEMS.filter(it=>it.d===d);
  launch("drill", items, 0, "Drill · Domain "+d+" · "+DOMAINS[d].name);
}

function drillMissed(){
  const items = ORDER.filter((it,i)=>!isCorrect(i));
  if(!items.length) return;
  launch("drill", items, 0, "Drill · items you missed");
}

function drillFragile(){
  const items = ORDER.filter((it,i)=>UNSURE[i]);
  if(!items.length) return;
  launch("drill", items, 0, "Drill · items you marked unsure");
}

function drillWeakest(){
  const per = {};
  ORDER.forEach((it,i)=>{ per[it.d]=per[it.d]||{n:0,c:0}; per[it.d].n++; if(isCorrect(i)) per[it.d].c++; });
  let worst = null, worstPct = 2;
  Object.keys(per).forEach(d=>{ const p=per[d].c/per[d].n; if(p<worstPct){worstPct=p; worst=+d;} });
  if(worst) drillDomain(worst);
}

function launch(mode, items, minutes, label){
  if(!items || !items.length) return;
  if(label.indexOf("Practice test") !== 0) CURRENT_FORM = null;
  MODE = mode; LABEL = label;
  ORDER = items.slice();
  PERM = ORDER.map(it=>shuffle(it.o.map((_,i)=>i)));   // perm[displayIdx] = storedIdx
  ANSWERS = ORDER.map(()=>[]); FLAGS = ORDER.map(()=>false);
  CHECKED = ORDER.map(()=>false); UNSURE = ORDER.map(()=>false);
  SPENT = ORDER.map(()=>0); ENTERED = Date.now(); STREAK = 0; BEST_STREAK = 0;
  CUR = 0; FILTER = "all";
  if(TIMER_ID) clearInterval(TIMER_ID);

  ["screen-home","screen-start","screen-results","screen-rules"].forEach(s=>$(s).classList.add("hidden"));
  $("screen-exam").classList.remove("hidden");
  $("tb-mode").textContent = label;
  $("tb-submit").textContent = (mode==="study"||mode==="drill") ? "Finish and score" : "End exam";

  const timed = minutes > 0;
  $("timer").classList.toggle("hidden", !timed);
  $("pace").classList.toggle("hidden", !timed);
  if(timed){
    TOTAL_SECONDS = SECONDS_LEFT = minutes*60;
    tick(); TIMER_ID = setInterval(tick, 1000);
  }
  render();
}

function tick(){
  if(SECONDS_LEFT <= 0){ clearInterval(TIMER_ID); submitExam(true); return; }
  SECONDS_LEFT--;
  const m = Math.floor(SECONDS_LEFT/60), s = SECONDS_LEFT%60;
  $("timer").textContent = m + ":" + String(s).padStart(2,"0");
  $("timer").classList.toggle("low", SECONDS_LEFT <= 300);
  updatePace();
}

function updatePace(){
  const el = $("pace");
  if(el.classList.contains("hidden")) return;
  const elapsed = TOTAL_SECONDS - SECONDS_LEFT;
  const perItem = TOTAL_SECONDS / ORDER.length;
  const expected = Math.floor(elapsed / perItem);
  const answered = ANSWERS.filter(a=>a.length>0).length;
  const delta = answered - expected;
  el.classList.remove("ahead","behind");
  if(delta >= 2){ el.textContent = "+"+delta+" ahead of pace"; el.classList.add("ahead"); }
  else if(delta <= -2){ el.textContent = Math.abs(delta)+" behind pace"; el.classList.add("behind"); }
  else el.textContent = "on pace";
}

/* ---------- render ---------- */
function render(){
  const it = ORDER[CUR], sc = SCENARIOS[it.s];
  $("scen-tag").textContent = "Scenario " + it.s;
  $("scen-title").textContent = sc.title;
  $("scen-desc").innerHTML = sc.desc;

  $("item-no").textContent = "Item " + (CUR+1);
  $("pill-format").textContent = it.m ? "Select TWO responses" : "Select ONE response";
  $("pill-format").classList.toggle("two", !!it.m);

  const gpill = $("pill-guide");
  if(gpill) gpill.classList.toggle("hidden", it.src !== "guide");

  const teaching = MODE === "study" || MODE === "drill";
  const dpill = $("pill-dom");
  dpill.classList.toggle("hidden", !teaching);
  if(teaching) dpill.textContent = "Task " + it.ts + " · " + TS[it.ts];

  if(navDocked()) renderPalette();

  const hb = $("pill-hist"), h = histFor(it.id);
  const showHist = teaching && h.missed > 0;
  hb.classList.toggle("hidden", !showHist);
  if(showHist) hb.textContent = "Missed before ×" + h.missed;

  const sp = $("pill-streak");
  const showStreak = teaching && STREAK >= 3;
  sp.classList.toggle("hidden", !showStreak);
  if(showStreak) sp.textContent = STREAK + " in a row";

  $("pill-flag").classList.toggle("hidden", !FLAGS[CUR]);
  $("pill-unsure").classList.toggle("hidden", !UNSURE[CUR]);
  $("qtext").innerHTML = it.q;

  const revealed = teaching && CHECKED[CUR];
  $("opts").innerHTML = PERM[CUR].map((storedIdx,i)=>{
    const sel = ANSWERS[CUR].includes(i);
    let cls = "opt" + (sel ? " selected" : "");
    if(revealed){
      if(it.c.includes(storedIdx)) cls += " correct";
      else if(sel) cls += " wrongpick";
    }
    return '<button class="'+cls+'" '+(revealed?"disabled":"")+' onclick="pick('+i+')">'+
           '<span class="letter">'+LETTERS[i]+'</span><span class="txt">'+it.o[storedIdx]+'</span></button>';
  }).join("");

  const fb = $("feedback");
  if(teaching){
    $("checkrow").classList.toggle("hidden", revealed);
    const btn = $("check-btn"), need = it.m ? 2 : 1;
    btn.disabled = ANSWERS[CUR].length !== need;
    btn.textContent = ANSWERS[CUR].length !== need
      ? (it.m ? "Select two answers to check" : "Select an answer to check")
      : "Check answer";
    if(revealed){
      const ok = isCorrect(CUR), p = PRINCIPLES[it.p], s2d = storedToDisplay(CUR);
      fb.className = "feedback " + (ok ? "good" : "bad");
      fb.innerHTML =
        '<div class="verdict">'+(ok?"Correct":"Incorrect")+' · Answer: '+
          it.c.map(i=>LETTERS[s2d[i]]).sort().join(" and ")+'</div>'+
        '<div>'+remapExp(it.e, s2d)+'</div>'+
        '<div class="prin"><b>Rule</b>'+p.r+'</div>'+
        '<div class="prin trap"><b>What makes the wrong answer tempting</b>'+p.t+'</div>'+
        (it.cf ? '<div class="prin contrast"><b>Near-identical question, different answer</b>'+it.cf+'</div>' : '');
      fb.classList.remove("hidden");
    } else fb.classList.add("hidden");
  } else {
    $("checkrow").classList.add("hidden");
    fb.classList.add("hidden");
  }

  $("btn-prev").disabled = CUR === 0;
  $("btn-next").classList.toggle("hidden", CUR === ORDER.length-1);
  $("btn-finish").classList.toggle("hidden", CUR !== ORDER.length-1);
  $("btn-flag").classList.toggle("flag-on", FLAGS[CUR]);
  $("btn-flag").textContent = FLAGS[CUR] ? "Unflag" : "Flag";
  $("btn-unsure").classList.toggle("unsure-on", UNSURE[CUR]);
  $("btn-unsure").textContent = UNSURE[CUR] ? "Unsure ✓" : "Mark unsure";

  const answered = ANSWERS.filter(a=>a.length>0).length;
  $("nav-progress").textContent = (CUR+1) + " of " + ORDER.length + " · " + answered + " answered";
  updatePace();
  window.scrollTo({top:0, behavior:"instant"});
}

function pick(i){
  const it = ORDER[CUR];
  if((MODE==="study"||MODE==="drill") && CHECKED[CUR]) return;
  let a = ANSWERS[CUR];
  if(it.m){
    if(a.includes(i)) a = a.filter(x=>x!==i);
    else { a = a.concat([i]); if(a.length > 2) a.shift(); }
  } else a = a.includes(i) ? [] : [i];
  ANSWERS[CUR] = a.sort((x,y)=>x-y);
  render();
}

function checkAnswer(){
  CHECKED[CUR] = true;
  markTime();
  if(isCorrect(CUR)){ STREAK++; BEST_STREAK = Math.max(BEST_STREAK, STREAK); } else { STREAK = 0; }
  render();
}
function toggleFlag(){ FLAGS[CUR] = !FLAGS[CUR]; render(); }
function toggleUnsure(){ UNSURE[CUR] = !UNSURE[CUR]; render(); }
function markTime(){ if(ENTERED){ SPENT[CUR] += (Date.now() - ENTERED)/1000; } ENTERED = Date.now(); }
function go(step){ const n = CUR+step; if(n<0||n>=ORDER.length) return; markTime(); CUR = n; render(); }
function toggleScen(){
  const hidden = $("scen-desc").classList.toggle("hidden");
  $("scen-toggle").textContent = hidden ? "show brief" : "hide brief";
}

/* ---------- palette ---------- */
const DOMAIN_SHORT = {1:"Agentic", 2:"Tools", 3:"Config", 4:"Prompts", 5:"Context"};
let PAL_FILTER = "all";

function setPalFilter(f){ PAL_FILTER = f; openPalette(); }

function palMatches(it, idx){
  if(PAL_FILTER === "all") return true;
  if(PAL_FILTER === "flagged") return !!FLAGS[idx];
  return "d" + it.d === PAL_FILTER;
}

function renderPalette(){
  const remaining = ORDER.filter((it,i)=>!ANSWERS[i].length).length;
  const rem = $("pal-remaining");
  if(rem) rem.textContent = remaining;

  const perDomain = {}, flagged = ORDER.filter((it,i)=>FLAGS[i]).length;
  ORDER.forEach(it=>{ perDomain[it.d] = (perDomain[it.d] || 0) + 1; });

  let chips = '<button class="nav-chip' + (PAL_FILTER==="all" ? " on" : "") +
    '" data-pf="all">Overview <b>' + ORDER.length + '</b></button>' +
    '<button class="nav-chip' + (PAL_FILTER==="flagged" ? " on" : "") +
    '" data-pf="flagged">Flagged <b>' + flagged + '</b></button>';
  Object.keys(DOMAINS).forEach(d=>{
    if(!perDomain[d]) return;
    chips += '<button class="nav-chip d' + d + (PAL_FILTER==="d"+d ? " on" : "") +
      '" data-pf="d' + d + '" title="' + DOMAINS[d].name + '"><i></i>' +
      DOMAIN_SHORT[d] + ' <b>' + perDomain[d] + '</b></button>';
  });
  const filt = $("pal-filters");
  if(filt){
    filt["inner" + "HTML"] = chips;
    filt.onclick = function(ev){
      const b = ev.target.closest("[data-pf]");
      if(b) setPalFilter(b.getAttribute("data-pf"));
    };
  }

  const groups = {};
  ORDER.forEach((it,idx)=>{ if(palMatches(it,idx)) (groups[it.s] = groups[it.s] || []).push(idx); });
  const body = Object.keys(groups).map(sid=>{
    const btns = groups[sid].map(idx=>{
      let cls = "pal-btn";
      if(ANSWERS[idx].length) cls += " answered";
      if(FLAGS[idx]) cls += " flagged";
      if(UNSURE[idx]) cls += " unsure";
      if(idx === CUR) cls += " current";
      return '<button class="'+cls+'" onclick="jump('+idx+')">'+(idx+1)+'</button>';
    }).join("");
    return '<div class="pal-scen">Scenario '+sid+' · '+SCENARIOS[sid].title+'</div><div class="pal-grid">'+btns+'</div>';
  }).join("");
  $("pal-body")[["inner" + "HTML"]] = body || '<div class="pal-empty">Nothing matches this filter yet.</div>';

}

function openPalette(){ renderPalette(); $("palette").classList.remove("hidden"); }
function navDocked(){ return window.matchMedia("(min-width:1280px)").matches; }
function closePalette(){ if(navDocked()) return; $("palette").classList.add("hidden"); }
function jump(i){ markTime(); CUR = i; closePalette(); render(); }

/* ---------- scoring ---------- */
function isCorrect(idx){
  const it = ORDER[idx];
  const stored = ANSWERS[idx].map(dI=>PERM[idx][dI]);
  return stored.length === it.c.length && it.c.every(c=>stored.includes(c));
}
function displayKey(idx){                       // correct answers, as displayed
  return PERM[idx].map((sI,dI)=>it_c(idx).includes(sI) ? dI : -1).filter(x=>x>=0).sort((a,b)=>a-b);
}
function it_c(idx){ return ORDER[idx].c; }
function storedToDisplay(idx){
  const m = {}; PERM[idx].forEach((sI,dI)=>{ m[sI] = dI; }); return m;
}
const EXP_RE = /(Options?\s+[A-E](?:\s*,?\s*(?:and\s+)?[A-E])*)|(\(\s*[A-E](?:\s*(?:,|and|or)\s*[A-E])*\s*\))/g;
function remapExp(text, s2d){
  return text.replace(EXP_RE, span=>{
    const mapped = [...span.matchAll(/[A-E]/g)]
      .map(x=>LETTERS[s2d[LETTERS.indexOf(x[0])]]).sort();
    let k = 0;
    return span.replace(/[A-E]/g, ()=>mapped[k++]);
  });
}

function confirmSubmit(){
  const un = ANSWERS.filter(a=>a.length===0).length;
  const msg = un ? un + " item(s) are unanswered and will be scored as incorrect. Submit anyway?"
                 : "Submit and score?";
  if(confirm(msg)) submitExam(false);
}

function submitExam(timedOut){
  if(TIMER_ID) clearInterval(TIMER_ID);
  const total = ORDER.length;
  let correct = 0, fragile = 0, luckyOrSolid = 0;
  const perDom = {}, perPrin = {};
  ORDER.forEach((it,idx)=>{
    const ok = isCorrect(idx);
    perDom[it.d] = perDom[it.d] || {n:0,c:0};
    perDom[it.d].n++; if(ok) perDom[it.d].c++;
    perPrin[it.p] = perPrin[it.p] || {n:0,miss:0,items:[]};
    perPrin[it.p].n++;
    if(!ok){ perPrin[it.p].miss++; perPrin[it.p].items.push(idx+1); }
    if(ok) correct++;
    if(ok && UNSURE[idx]) fragile++;
    if(UNSURE[idx]) luckyOrSolid++;
  });
  // Scaled score follows the published blueprint weights rather than raw item counts,
  // renormalized over the domains actually present in this sitting.
  let wSum = 0, wAcc = 0;
  Object.keys(perDom).forEach(d=>{
    const w = DOMAINS[d].weight;
    wSum += w; wAcc += w * (perDom[d].c / perDom[d].n);
  });
  const wPct = wSum ? wAcc/wSum : 0;
  const pct = correct/total;
  const scaled = Math.round(100 + wPct*900), passed = scaled >= 720;
  const isDrill = MODE === "drill";

  $("screen-exam").classList.add("hidden");
  $("palette").classList.add("hidden");
  $("screen-results").classList.remove("hidden");

  $("res-eyebrow").textContent = (isDrill ? LABEL : "Score report") + (timedOut ? " · time expired" : "");
  $("res-score").textContent = isDrill ? Math.round(pct*100)+"%" : scaled.toLocaleString();
  $("res-cap").textContent = isDrill ? "Items correct" : "Scaled score (100–1,000)";
  const badge = $("res-verdict");
  badge.classList.toggle("hidden", isDrill);
  badge.textContent = passed ? "Pass" : "Did not pass";
  badge.className = "verdict-badge " + (passed ? "pass" : "fail") + (isDrill ? " hidden" : "");

  let meta = correct + " of " + total + " items correct (" + Math.round(pct*100) + "%)";
  if(!isDrill) meta += "<br>Blueprint-weighted " + Math.round(wPct*100) + "% · cut score 720 is 69% weighted";
  if(luckyOrSolid) meta += "<br>" + luckyOrSolid + " marked unsure · " + fragile + " of those were correct anyway";
  $("res-meta").innerHTML = meta;

  $("band-wrap").classList.toggle("hidden", isDrill);
  if(!isDrill){
    const pos = ((scaled-100)/900)*100;
    $("band-fill").style.width = pos + "%";
    $("band-fill").style.background = passed ? "var(--pass)" : "var(--signal)";
    $("band-cut").style.left = (((720-100)/900)*100) + "%";
    $("band-marker").style.left = pos + "%";
  }

  $("domtable").innerHTML = Object.keys(DOMAINS).map(k=>{
    const d = DOMAINS[k], r = perDom[k];
    if(!r) return "";
    const p = Math.round((r.c/r.n)*100);
    return '<tr><td style="width:44%">Domain '+k+' · '+d.name+'</td>'+
           '<td><div class="dt-bar"><div class="dt-fill" style="width:'+p+'%"></div></div></td>'+
           '<td class="pct">'+p+'% &nbsp;('+r.c+'/'+r.n+')</td></tr>';
  }).join("");

  /* a domain you blanked can still total to a pass here; on another form it will not */
  const weak = Object.keys(perDom).filter(d=>perDom[d].c/perDom[d].n < 0.6)
    .sort((a,b)=>(perDom[a].c/perDom[a].n)-(perDom[b].c/perDom[b].n));
  $("risk").innerHTML = (isDrill || !weak.length) ? "" :
    '<div class="risk"><b>Exposure</b>' +
    weak.map(d=>'Domain '+d+' is '+DOMAINS[d].weight+'% of the exam and you scored '+Math.round(perDom[d].c/perDom[d].n*100)+'%').join('. ') +
    '. Pass or fail is decided by the total, so a gap this size can pass on one form and fail on another. Drill it before you sit the real exam.</div>';

  /* priority review: principles you missed, worst first */
  const missed = Object.keys(perPrin).filter(k=>perPrin[k].miss>0)
    .sort((a,b)=> perPrin[b].miss - perPrin[a].miss || perPrin[b].n - perPrin[a].n);
  const tsFor = pid => [...new Set(ORDER.filter(it=>it.p===pid).map(it=>it.ts))].sort();
  $("priority").innerHTML = missed.length ? missed.map(pid=>{
    const p = PRINCIPLES[pid], r = perPrin[pid];
    return '<div class="prio-card"><div class="prio-top">'+
      '<span class="prio-count">'+r.miss+' of '+r.n+' missed</span>'+
      '<span>Domain '+p.d+'</span>'+
      '<span>Re-read '+tsFor(pid).map(t=>"Task "+t).join(", ")+'</span>'+
      '<span>Items '+r.items.join(", ")+'</span></div>'+
      '<div class="prio-rule">'+p.r+'</div>'+
      '<div class="prio-trap"><b>Why the wrong answer looked right</b>'+p.t+'</div></div>';
  }).join("") : '<p style="color:var(--muted);font-size:14px;">Nothing missed. Check the items you marked unsure below.</p>';

  $("btn-drill-missed").disabled = correct === total;
  $("btn-drill-fragile").disabled = luckyOrSolid === 0;

  ORDER.forEach((it,idx)=>{
    const h = histFor(it.id);
    HIST[it.id] = { seen: h.seen + 1, missed: h.missed + (isCorrect(idx) ? 0 : 1), ok: isCorrect(idx) ? 1 : 0 };
  });
  saveHist(); refreshHistUI(); renderMastery();
  if(CURRENT_FORM && !isDrill){
    const prev = FORMS["f"+CURRENT_FORM];
    if(!prev || scaled > prev.scaled) FORMS["f"+CURRENT_FORM] = {scaled: scaled, pct: Math.round(pct*100)};
    saveForms(); renderForms();
  }

  markTime();
  const timedSitting = TOTAL_SECONDS > 0;
  const rushed = ORDER.map((it,i)=>({i:i+1, t:SPENT[i]}))
    .filter(r=>timedSitting && !isCorrect(r.i-1) && r.t < 25)
    .map(r=>({i:r.i, t:Math.max(1, Math.round(r.t))}));
  const rushEl = $("rushed");
  if(rushEl){
    rushEl.innerHTML = (isDrill || !rushed.length) ? "" :
      '<div class="rushed"><b>Answered fast, got wrong</b>Items ' +
      rushed.map(r=>r.i + " (" + r.t + "s)").join(", ") +
      '. On a 2-minute-per-item budget these were the ones you did not stop to read. Worth checking whether you misread the stem or genuinely did not know.</div>';
  }
  if(BEST_STREAK >= 5){
    const st = $("streak-note");
    if(st) st.textContent = "Longest run of correct answers: " + BEST_STREAK + ".";
  }

  renderReview();
  window.scrollTo({top:0, behavior:"instant"});
}

function setFilter(f){
  FILTER = f;
  ["all","wrong","unsure"].forEach(k=>$("f-"+k).classList.toggle("on", f===k));
  renderReview();
}

function renderReview(){
  const rows = [];
  ORDER.forEach((it,idx)=>{
    const ok = isCorrect(idx);
    if(FILTER === "wrong" && ok) return;
    if(FILTER === "unsure" && !UNSURE[idx]) return;
    const s2d = storedToDisplay(idx);
    const opts = PERM[idx].map((storedIdx,i)=>{
      let cls = "rev-opt";
      if(it.c.includes(storedIdx)) cls += " is-correct";
      else if(ANSWERS[idx].includes(i)) cls += " is-wrongpick";
      const mark = ANSWERS[idx].includes(i) ? " &nbsp;<em style='font-style:normal;font-size:12px;'>(your answer)</em>" : "";
      return '<div class="'+cls+'"><span class="l">'+LETTERS[i]+'</span><span>'+it.o[storedIdx]+mark+'</span></div>';
    }).join("");
    const p = PRINCIPLES[it.p];
    rows.push(
      '<div class="rev-card"><div class="rev-top">'+
      '<span class="rev-mark '+(ok?"ok":"no")+'">'+(ok?"Correct":"Incorrect")+'</span>'+
      (UNSURE[idx] ? '<span class="rev-mark uns">Marked unsure</span>' : '')+
      '<span>Item '+(idx+1)+'</span>'+
      '<span>Scenario '+it.s+' · '+SCENARIOS[it.s].title+'</span>'+
      '<span>Domain '+it.d+' · Task '+it.ts+' · '+TS[it.ts]+'</span>'+
      (ANSWERS[idx].length ? "" : '<span>Not answered</span>')+
      '</div><div class="rev-q">'+it.q+'</div>'+opts+
      '<div class="rev-exp"><b>Why</b>'+remapExp(it.e, s2d)+'</div>'+
      '<div class="rev-exp"><b>Rule</b>'+p.r+'</div>'+
      '<div class="rev-exp"><b>What makes the wrong answer tempting</b>'+p.t+'</div>'+
      (it.cf ? '<div class="rev-exp"><b>Near-identical question, different answer</b>'+it.cf+'</div>' : '')+'</div>'
    );
  });
  $("review").innerHTML = rows.length ? rows.join("")
    : '<p style="color:var(--muted);font-size:14px;">No items in this filter.</p>';
}

/* ---------- rule sheet ---------- */
function openRules(from){
  RULES_RETURN = from || "screen-start";
  const byDom = {};
  Object.keys(PRINCIPLES).forEach(k=>{ const p=PRINCIPLES[k]; (byDom[p.d]=byDom[p.d]||[]).push(k); });
  $("rules-body").innerHTML = Object.keys(byDom).sort().map(d=>
    '<h2>Domain '+d+' · '+DOMAINS[d].name+'</h2>' +
    byDom[d].map(k=>{
      const p = PRINCIPLES[k];
      return '<div class="rule-card"><div class="rule-r">'+p.r+'</div>'+
             '<div class="rule-t"><b>Trap</b>'+p.t+'</div></div>';
    }).join("")
  ).join("");
  ["screen-home","screen-start","screen-exam","screen-results"].forEach(s=>$(s).classList.add("hidden"));
  $("screen-rules").classList.remove("hidden");
  window.scrollTo({top:0, behavior:"instant"});
}
function closeRules(){
  $("screen-rules").classList.add("hidden");
  $(RULES_RETURN).classList.remove("hidden");
  window.scrollTo({top:0, behavior:"instant"});
}

/* ---------- keyboard ---------- */
document.addEventListener("keydown", e=>{
  if($("screen-exam").classList.contains("hidden")) return;
  if(!$("palette").classList.contains("hidden")){ if(e.key==="Escape") closePalette(); return; }
  if(e.key === "ArrowRight") go(1);
  else if(e.key === "ArrowLeft") go(-1);
  else if(e.key.toLowerCase() === "u") toggleUnsure();
  else if(e.key.toLowerCase() === "f") toggleFlag();
  else if(/^[1-5]$/.test(e.key)){
    const i = parseInt(e.key,10)-1;
    if(i < ORDER[CUR].o.length) pick(i);
  }
});
</script>
