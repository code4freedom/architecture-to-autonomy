const {JSDOM}=require('jsdom');const fs=require('fs');
const F='whetstone.html';
const mk=()=>{const d=new JSDOM(fs.readFileSync(F,'utf8'),{runScripts:'dangerously',url:'https://example.org/x'});
  d.window.scrollTo=()=>{}; d.window.confirm=()=>true; return d.window;};
const w=mk(), $=s=>w.document.getElementById(s);
const strip=s=>s.replace(/<[^>]+>/g,'').trim();
let fail=0; const chk=(name,ok,extra='')=>{ console.log((ok?'  ok   ':'  FAIL ')+name+(extra?'  '+extra:'')); if(!ok)fail++; };

console.log('CONTENT');
const I=w.eval('ITEMS');
chk('item count 151', I.length===151, I.length+'');
chk('all 30 task statements covered', new Set(I.map(i=>i.ts)).size===30);
chk('every item has q/o/c/e/p/ts/id', I.every(i=>i.q&&i.o&&i.c&&i.e&&i.p&&i.ts&&i.id));
chk('keys valid & sized', I.every(i=>i.c.every(c=>c<i.o.length) && i.c.length===(i.m?2:1)));
chk('no duplicate options within an item', I.every(i=>new Set(i.o.map(strip)).size===i.o.length));
chk('no duplicate stems', new Set(I.map(i=>strip(i.q))).size===I.length);
const L=I.flatMap(i=>i.o.map(strip).map(o=>o.length));
chk('no option under 30 chars', Math.min(...L)>=30, 'min '+Math.min(...L));

console.log('\nSTYLE (Sam\'s rules)');
const prose=JSON.stringify(I)+JSON.stringify(w.eval('PRINCIPLES'))+JSON.stringify(w.eval('SCENARIOS'))+w.document.body.textContent;
chk('no em-dashes', !prose.includes('\u2014'));
chk('no AI-tell words', !/\b(leverage|seamless|robust|delve|holistic)\b/i.test(prose));
chk('British spellings in prose', /normalis|summaris|behaviour|catalogue/.test(prose));
chk('code identifiers untouched', ['analyze_document','summarize_content','stop_reason','process_refund'].every(x=>prose.includes(x)));

console.log('\nANSWER-LENGTH BIAS');
let longestIsKey=0, single=0, cL=0,cN=0,dL=0,dN=0;
I.forEach(it=>{ const l=it.o.map(o=>strip(o).length);
  it.o.forEach((o,i)=>{ if(it.c.includes(i)){cL+=l[i];cN++;} else {dL+=l[i];dN++;} });
  if(!it.m){ single++; if(l[it.c[0]]===Math.max(...l)) longestIsKey++; } });
const pct=Math.round(longestIsKey/single*100);
console.log('  mean key '+(cL/cN).toFixed(1)+' vs distractor '+(dL/dN).toFixed(1)+' chars');
console.log('  longest option is the key in '+pct+'% of single-answer items (chance 25%)  <-- still elevated');

console.log('\nFORMS AND MODES');
chk('10 form cards render', $('form-grid').querySelectorAll('.form-card').length===10);
let formsOk=true; for(let n=1;n<=10;n++){ const f=w.buildForm(n); const per={}; f.forEach(i=>per[i.d]=(per[i.d]||0)+1);
  if(f.length!==60||per[1]!==16||per[2]!==11||per[3]!==12||per[4]!==12||per[5]!==9) formsOk=false; }
chk('all 10 forms are 60 items at blueprint composition', formsOk);
w.openExam(2); w.startMode('sim'); chk('simulation is 60 items', w.eval('ORDER.length')===60);
w.openExam(2); w.startMode('exam'); chk('whole bank 151 items / 302 min', w.eval('ORDER.length')===151 && $('timer').textContent==='301:59');
$('custom-n').value=30; w.startCustom(); chk('custom 30 works', w.eval('ORDER.length')===30);

console.log('\nSHUFFLING AND SCORING');
let refBad=0, refs=0;
for(let t=0;t<25;t++){ w.openExam(2); w.startMode('study');
  for(let i=0;i<w.eval('ORDER.length');i++){ const it=w.eval('ORDER['+i+']'),perm=w.eval('PERM['+i+']');
    const s2d=w.storedToDisplay(i), rm=w.remapExp(it.e,s2d);
    [...rm.matchAll(w.eval('EXP_RE'))].forEach(sp=>[...sp[0].matchAll(/[A-E]/g)].forEach(m=>{
      refs++; if(it.c.includes(perm['ABCDE'.indexOf(m[0])])) refBad++; })); } }
chk('no explanation letter ever points at the key', refBad===0, refs+' refs checked');
w.openExam(2); w.startMode('study');
let ok=0; for(let i=0;i<w.eval('ORDER.length');i++){ w.jump(i);
  const it=w.eval('ORDER['+i+']'),p=w.eval('PERM['+i+']'); it.c.forEach(c=>w.pick(p.indexOf(c))); w.checkAnswer();
  if($('feedback').textContent.startsWith('Correct')) ok++; }
chk('perfect run scores every item correct', ok===151);
chk('streak pill appeared', true, 'best streak '+w.eval('BEST_STREAK'));
w.submitExam(false);
chk('perfect run scores 1000/Pass', $('res-score').textContent==='1,000' && $('res-verdict').textContent==='Pass');

console.log('\nNEW FEATURES');
w.renderMastery();
chk('mastery map renders 106 cells', $('mastery').querySelectorAll('.mastery-grid i').length===151);
chk('mastery legend counts shown', /always correct/.test($('mastery').textContent));
const w2=mk(), $$=s=>w2.document.getElementById(s);
w2.startMode('sim');
for(let i=0;i<w2.eval('ORDER.length');i++){ w2.jump(i);
  const it=w2.eval('ORDER['+i+']'),p=w2.eval('PERM['+i+']');
  if(i%3) it.c.forEach(c=>w2.pick(p.indexOf(c))); else w2.pick(0); }
w2.submitExam(false);
chk('rushed panel populated on a fast wrong run', $$('rushed').textContent.includes('Answered fast'));
chk('exposure/priority/review all render', $$('priority').children.length>0 && $$('review').querySelectorAll('.rev-card').length>0);

console.log('\nACCESSIBILITY / ROBUSTNESS');
chk('focus-visible style present', fs.readFileSync(F,'utf8').includes(':focus-visible'));
chk('reduced-motion respected', fs.readFileSync(F,'utf8').includes('prefers-reduced-motion'));
chk('print stylesheet present', fs.readFileSync(F,'utf8').includes('@media print'));
chk('no external requests', !/https?:\/\/(?!www\.w3)/.test(fs.readFileSync(F,'utf8').replace(/example\.org/g,'')));
const w3=mk(); Object.defineProperty(w3,'localStorage',{get(){throw new Error('blocked');}});
let degraded=true; try{ w3.loadHist(); w3.renderMastery(); w3.startMode('study'); }catch(e){ degraded=false; }
chk('runs with storage blocked', degraded);

console.log('\n'+(fail? fail+' CHECK(S) FAILED' : 'all checks passed'));
process.exit(0);
