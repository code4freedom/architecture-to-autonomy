/* Data used to upgrade the item bank. Node script, not shipped to the browser as-is. */
const PRINCIPLES = {
 "LOOP":{d:1,r:"Drive the agentic loop from <code>stop_reason</code>: continue on <code>tool_use</code>, terminate on <code>end_turn</code>, appending tool results to the conversation between iterations.",t:"Anything that reads the assistant's prose for a closing phrase, treats the presence of text as completion, or leans on an iteration cap as the primary stop. Caps are a safety net, never the mechanism."},
 "HOOKS":{d:1,r:"Hooks are the deterministic seam. Intercept outgoing tool calls to enforce business rules; use PostToolUse to normalize heterogeneous results before the model sees them.",t:"A well-written system prompt. If a rule must hold every time, prompt guidance and few-shot examples are the wrong instrument by construction, not merely a weaker one."},
 "DECOMP-MULTI":{d:1,r:"Break a multi-concern request into distinct items, investigate each against shared context, then synthesize one unified resolution.",t:"Escalating because the message is complicated, or asking the person to resubmit. Neither complexity nor concern count is an escalation trigger."},
 "HANDOFF":{d:1,r:"Escalations carry a structured summary: verified identifiers, root cause, amounts, recommended action.",t:"Attaching raw tool output or a confidence score. The receiving human has no transcript and no use for either."},
 "DECOMP-PATTERN":{d:1,r:"Match decomposition to predictability: prompt chaining and per-file passes for known aspects, adaptive decomposition for open-ended investigation, plus a separate integration pass for cross-file concerns.",t:"A larger context window. Attention dilution is not a capacity problem, and consensus filtering across repeated passes suppresses real findings."},
 "SESSIONS":{d:1,r:"Resume when prior context is mostly valid and say what changed, <code>fork_session</code> to explore divergent branches from one baseline, restart with an injected summary when tool results are stale.",t:"Resuming a session whose stored observations no longer match the files. Stale results are carried forward as though current."},
 "SUBAGENT-CTX":{d:1,r:"Subagents inherit nothing. <code>Task</code> must be in <code>allowedTools</code>, context goes in the prompt, and parallel means several Task calls emitted in one response.",t:"Assuming a shared session or shared memory, or spreading Task calls across turns and expecting the SDK to overlap them."},
 "COORDINATOR":{d:1,r:"The coordinator owns scope: it selects which subagents to run, states goals and quality criteria rather than procedures, and loops back when synthesis reveals gaps.",t:"Blaming a downstream agent that executed its assignment correctly. Ask what an agent was assigned before asking how it performed."},

 "TOOL-BOUNDARY":{d:2,r:"Fix tool problems in the tool: sharpen descriptions first, split overloaded tools into purpose-specific ones, replace generic tools with constrained alternatives.",t:"Few-shot examples, routing layers, or repair hooks bolted onto a tool whose contract is the actual defect. Descriptions are the primary selection mechanism, so they are usually the cheapest first step."},
 "ERRORS":{d:2,r:"Errors return category (transient / validation / business / permission), an <code>isRetryable</code> flag, and a human-readable description.",t:"Uniform \"operation failed\", or returning empty success to stop the retries. Both destroy the information the agent needs to recover."},
 "LEAST-PRIV":{d:2,r:"Scope each agent's tools to its role, with narrow cross-role exceptions only where frequency justifies them.",t:"One shared tool set plus prompt instructions about who may use what. Too many tools degrades selection regardless of instructions."},
 "MCP-SCOPE":{d:2,r:"Project <code>.mcp.json</code> for shared servers with <code>${ENV_VAR}</code> expansion; user <code>~/.claude.json</code> for personal and experimental ones. All configured servers are available simultaneously.",t:"Committed tokens, or convention files pressed into service as server configuration."},
 "BUILTIN":{d:2,r:"Grep searches content, Glob matches paths, Edit needs a unique anchor with Read + Write as the fallback. Explore by searching entry points first, then reading along the path.",t:"Retrying an Edit that failed on a non-unique match, or reading breadth-first through a codebase you have not yet narrowed."},

 "HIERARCHY":{d:3,r:"User-level memory never travels through version control. Anything the team must follow lives at project level, and <code>/memory</code> tells you what actually loaded.",t:"Applying a fix before diagnosing which memory files are in play. Inconsistent behaviour across sessions is a hierarchy question first."},
 "MODULAR":{d:3,r:"Split standards into <code>.claude/rules/</code> topic files, scope them with <code>paths</code> globs, use <code>@import</code> for per-package relevance, and reserve skills for on-demand workflows.",t:"Directory-level CLAUDE.md for conventions that cut across directories, or a skill for standards that must always apply. Skills need invoking; CLAUDE.md is always loaded."},
 "FRONTMATTER":{d:3,r:"Match the frontmatter option to the problem: <code>context: fork</code> for verbose output, <code>allowed-tools</code> for capability limits, <code>argument-hint</code> for missing inputs.",t:"Using fork to prevent a destructive action. It isolates context, not capability."},
 "PLANMODE":{d:3,r:"Plan mode for large-scale change, several viable approaches, or architectural decisions; direct execution for well-scoped work; combine the two on a migration.",t:"Waiting for complexity to emerge when the brief already states it."},
 "REFINE":{d:3,r:"When prose keeps being read differently, switch instruments: two or three concrete input/output examples, a test suite you iterate against by sharing failures, or the interview pattern to surface considerations you have not thought of.",t:"Rewriting the prose more carefully, or relocating it. If three careful descriptions produced three readings, a fourth will not converge."},
 "CLI":{d:3,r:"CI runs use <code>-p</code> / <code>--print</code>, with <code>--output-format json</code> and <code>--json-schema</code> when a script parses the output.",t:"Invented flags and environment variables, or prompting for JSON and extracting it with a regex."},

 "CRITERIA":{d:4,r:"Precision comes from explicit categorical criteria and severity levels anchored in concrete code examples.",t:"\"Be conservative\", \"only report high-confidence findings\", or a numeric certainty threshold. General instructions do not improve precision."},
 "FEWSHOT":{d:4,r:"Few-shot examples are the instrument for output format and for ambiguous cases, and they generalize to novel patterns where enumerated rules do not.",t:"Reaching for few-shot when the real defect is a tool contract, a schema, or a missing enforcement gate."},
 "FEEDBACK-LOOP":{d:4,r:"Instrument findings with a <code>detected_pattern</code> field so dismissals can be grouped by construct and turned into prompt changes.",t:"Asking the model to predict whether a finding will be dismissed. That is another uncalibrated self-report."},
 "BATCH":{d:4,r:"Message Batches API for latency-tolerant work only: 50% cheaper, up to 24 hours, no SLA, <code>custom_id</code> for correlation, no multi-turn tool calling.",t:"Polling a batch inside a blocking workflow, or claiming batch results cannot be correlated back to requests."},
 "INDEPENDENT":{d:4,r:"Review needs outside context: a separate instance without the generator's reasoning, and prior findings passed forward so re-runs report only what is new or unaddressed.",t:"A skeptical persona or extended thinking inside the session that wrote the code."},
 "SCHEMA-FORM":{d:4,r:"Tool use with a JSON schema guarantees form, not truth. Syntax errors go away; semantic errors remain yours to validate.",t:"Treating a strict schema as an accuracy control."},
 "UNCERTAINTY":{d:4,r:"Give uncertainty somewhere honest to go: nullable and optional fields, an \"unclear\" enum value, \"other\" plus a detail string.",t:"Required fields for information the source may not contain. The model will fill them rather than fail the schema."},
 "TOOLCHOICE":{d:4,r:"<code>auto</code> permits text, <code>any</code> guarantees some tool, forced selection names the tool. Pick the guarantee the workflow needs, then continue in follow-up turns.",t:"Relying on tool order in the array, or on a prompt instruction, to sequence extraction steps."},
 "RETRY":{d:4,r:"Retry with the document, the failed extraction, and the specific validation error. It corrects format and structure.",t:"Retrying when the information is simply absent from the source. No amount of feedback manufactures it."},

 "FACTS":{d:5,r:"Lift transactional facts into a persistent block outside the summarized history, and trim verbose tool output before it accumulates.",t:"Tuning the summarizer. Progressive summarization degrades exactly the amounts, dates, and stated expectations you need."},
 "ESCALATE":{d:5,r:"Escalate on explicit signals: a request for a human, a policy gap or silence, or no meaningful progress. On multiple matches, ask for another identifier.",t:"Sentiment scores and self-reported confidence. Neither tracks case complexity, and the agent is already confident on the cases it gets wrong."},
 "PROPAGATE":{d:5,r:"Subagents recover locally from transient failures and propagate only what they cannot resolve, with failure type, what was attempted, partial results, and alternatives.",t:"A generic unavailable status, an empty result marked successful, or terminating the whole workflow on one failure."},
 "CONTEXT-LONG":{d:5,r:"Long sessions need isolation and persistence: delegate verbose discovery to subagents or Explore, keep a scratchpad of findings, <code>/compact</code> when discovery crowds out the plan.",t:"Assuming a session that has started citing \"typical patterns\" just needs a longer answer or a bigger window."},
 "PROVENANCE":{d:5,r:"Carry claim-to-source mappings and publication dates through every step, and annotate conflicts rather than resolving them.",t:"Averaging figures, picking the most authoritative source, or re-searching a claim afterwards to find some citation for it."},
 "SEGMENT":{d:5,r:"Before reducing human review, segment accuracy by document type and field; then sample the high-confidence population and calibrate field-level confidence on labelled data.",t:"A strong aggregate number. 97% overall can hide the one document type that will hurt you."}
};

const ITEM_3_5 = {
 s:2, d:3, p:"REFINE", ts:"3.5",
 q:"You have described the same log-normalization transform in prose three times, and each attempt handles nested nulls and empty arrays differently. The prose is detailed and you are running out of ways to phrase it. What is most likely to resolve this?",
 o:["Provide two or three concrete input and output examples covering the nesting cases you care about.",
    "Move the description into CLAUDE.md so it is applied consistently on every future session.",
    "Ask Claude to restate the requirement in its own words before implementing, and correct the restatement.",
    "Split the transform into four smaller functions and specify each one separately in prose."],
 c:[0],
 e:"When natural language descriptions produce inconsistent results, concrete input and output examples are the most effective way to communicate the expected transformation, because they pin down the exact cases prose keeps leaving ambiguous. Relocating the same prose to CLAUDE.md changes when it loads, not how it is read. Restatement surfaces misunderstandings but still trades in the prose that is failing; the related interview pattern is for surfacing considerations you have not thought of, not for pinning down a transform you have already specified. Decomposition multiplies the number of ambiguous prose specs."
};

const TS = {
 "1.1":"Agentic loops for autonomous task execution",
 "1.2":"Coordinator-subagent orchestration",
 "1.3":"Subagent invocation, context passing, and spawning",
 "1.4":"Multi-step workflows with enforcement and handoff",
 "1.5":"Agent SDK hooks for interception and normalization",
 "1.6":"Task decomposition strategies",
 "1.7":"Session state, resumption, and forking",
 "2.1":"Tool interfaces with clear descriptions and boundaries",
 "2.2":"Structured error responses for MCP tools",
 "2.3":"Tool distribution across agents and tool choice",
 "2.4":"MCP server integration",
 "2.5":"Built-in tool selection",
 "3.1":"CLAUDE.md hierarchy, scoping, and modular organization",
 "3.2":"Custom slash commands and skills",
 "3.3":"Path-specific rules for conditional convention loading",
 "3.4":"Plan mode vs direct execution",
 "3.5":"Iterative refinement for progressive improvement",
 "3.6":"Claude Code in CI/CD pipelines",
 "4.1":"Explicit criteria to reduce false positives",
 "4.2":"Few-shot prompting for consistency",
 "4.3":"Structured output via tool use and JSON schemas",
 "4.4":"Validation, retry, and feedback loops",
 "4.5":"Batch processing strategies",
 "4.6":"Multi-instance and multi-pass review",
 "5.1":"Conversation context across long interactions",
 "5.2":"Escalation and ambiguity resolution",
 "5.3":"Error propagation across multi-agent systems",
 "5.4":"Context in large codebase exploration",
 "5.5":"Human review workflows and confidence calibration",
 "5.6":"Provenance and uncertainty in multi-source synthesis"
};

/* item index -> [principle, task statement] */
const MAP = [
 ["LOOP","1.1"],["HOOKS","1.5"],["DECOMP-MULTI","1.4"],["HANDOFF","1.4"],["HOOKS","1.5"],
 ["ERRORS","2.2"],["TOOL-BOUNDARY","2.1"],["FACTS","5.1"],["ESCALATE","5.2"],["ESCALATE","5.2"],
 ["HIERARCHY","3.1"],["MODULAR","3.1"],["FRONTMATTER","3.2"],["FRONTMATTER","3.2"],["FRONTMATTER","3.2"],
 ["PLANMODE","3.4"],["HIERARCHY","3.1"],["CONTEXT-LONG","5.4"],["SESSIONS","1.7"],["DECOMP-PATTERN","1.6"],
 ["SUBAGENT-CTX","1.3"],["SUBAGENT-CTX","1.3"],["SUBAGENT-CTX","1.3"],["COORDINATOR","1.2"],["COORDINATOR","1.2"],
 ["COORDINATOR","1.3"],["LEAST-PRIV","2.3"],["PROPAGATE","5.3"],["PROVENANCE","5.6"],["PROVENANCE","5.6"],
 ["BUILTIN","2.5"],["BUILTIN","2.5"],["MCP-SCOPE","2.4"],["TOOL-BOUNDARY","2.4"],["BUILTIN","2.5"],
 ["CONTEXT-LONG","5.4"],["SESSIONS","1.7"],["CONTEXT-LONG","3.4"],["MODULAR","3.3"],["MODULAR","3.2"],
 ["CLI","3.6"],["CLI","3.6"],["CRITERIA","4.1"],["FEWSHOT","4.2"],["CRITERIA","4.1"],
 ["FEEDBACK-LOOP","4.4"],["BATCH","4.5"],["INDEPENDENT","4.6"],["DECOMP-PATTERN","1.6"],["INDEPENDENT","3.6"],
 ["SCHEMA-FORM","4.3"],["UNCERTAINTY","4.3"],["TOOLCHOICE","4.3"],["TOOLCHOICE","4.3"],["UNCERTAINTY","4.3"],
 ["RETRY","4.4"],["SEGMENT","5.5"],["SEGMENT","5.5"],["ERRORS","2.2"],["TOOL-BOUNDARY","2.1"]
];

/* replacement for index 27: covers Task Statement 5.3, previously unrepresented */
const ITEM27 = {
 s:3, d:5,
 q:"Your document-analysis subagent hits a parser failure on two of the six PDFs it was assigned, after successfully extracting findings from the other four. It has already retried both twice. What should it return to the coordinator?",
 o:["A generic \"document analysis unavailable\" status, so the coordinator can cleanly retry the whole assignment.",
    "An empty result set marked successful, so the pipeline continues without a failure branch.",
    "Structured error context: the failure type, which documents failed, the findings already extracted from the four that succeeded, and alternative approaches worth trying.",
    "The parser exception itself, propagated to a top-level handler that terminates the research run."],
 c:[2],
 e:"Subagents recover locally where they can and propagate what they cannot resolve, together with what was attempted and any partial results, so the coordinator can decide whether to retry differently, substitute sources, or proceed and annotate the coverage gap. A generic status hides that context. Marking failure as success suppresses the error entirely and risks a report that silently omits two sources. Terminating the run discards four successful analyses over a partial failure."
};

module.exports = { PRINCIPLES, TS, MAP, ITEM27, ITEM_3_5 };
