const fs = require('fs');
const { PRINCIPLES, TS, MAP, ITEM27, ITEM_3_5 } = require('./upgrade-data.js');
const BATCH_A = require('./batchA.js');
const BATCH_B = require('./batchB.js');
const BATCH_C = require('./batchC.js');
const BATCH_D = require('./batchD.js');
const BATCH_E = require('./batchE.js');

let h = fs.readFileSync('shell.html','utf8');   // the unbuilt HTML shell
const blocks = [...h.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
global.document = {getElementById:()=>({innerHTML:'',classList:{add(){},remove(){},toggle(){}},style:{},textContent:''}),addEventListener:()=>{}};
global.window = {scrollTo:()=>{}};
eval(blocks[0] + '; globalThis.__I=ITEMS; globalThis.__D=DOMAINS; globalThis.__S=SCENARIOS;');
const ITEMS = globalThis.__I, DOMAINS = globalThis.__D, SCENARIOS = globalThis.__S;

/* --- content edits --- */
ITEMS[27] = ITEM27;          // adds coverage of Task Statement 5.3
ITEMS[18].d = 1;             // session resumption -> Task 1.7 / Domain 1
ITEMS[4].d  = 1;             // PostToolUse normalization -> Task 1.5 / Domain 1
ITEMS[34].d = 2;             // incremental codebase exploration -> Task 2.5 / Domain 2
ITEMS[35].d = 5;             // subagent delegation for verbose exploration -> Task 5.4 / Domain 5
ITEMS[49].d = 3;             // carrying prior review findings -> Task 3.6 / Domain 3
ITEMS.forEach((it,i)=>{ it.p = MAP[i][0]; it.ts = MAP[i][1]; });
ITEMS.splice(15, 0, ITEM_3_5);   // Task 3.5 was the one task statement with no item
BATCH_A.concat(BATCH_B, BATCH_C, BATCH_D, BATCH_E).forEach(it=>ITEMS.push(it));
ITEMS.forEach((it,i)=>{ it.id = 'q' + String(i+1).padStart(3,'0'); });

/* --- integrity checks --- */
const L=["A","B","C","D","E"];
let problems=[];
ITEMS.forEach((it,i)=>{
  if(!PRINCIPLES[it.p]) problems.push('item '+(i+1)+' unknown principle '+it.p);
  if(!TS[it.ts]) problems.push('item '+(i+1)+' unknown task statement '+it.ts);
  if(it.ts[0] !== String(it.d)) problems.push('item '+(i+1)+' task '+it.ts+' outside domain '+it.d);
  if(it.m && it.c.length!==2) problems.push('item '+(i+1)+' multi key size');
  if(!it.m && it.c.length!==1) problems.push('item '+(i+1)+' single key size');
});
const pos={}; ITEMS.filter(i=>!i.m).forEach(i=>pos[i.c[0]]=(pos[i.c[0]]||0)+1);
const perD={}; ITEMS.forEach(i=>perD[i.d]=(perD[i.d]||0)+1);
console.log('total items:', ITEMS.length);
const FORM_NEED = {1:16,2:11,3:12,4:12,5:9};
Object.keys(FORM_NEED).forEach(d=>{
  const have = ITEMS.filter(i=>i.d==d).length;
  if(have < FORM_NEED[d]) problems.push('domain '+d+' pool '+have+' < per-form need '+FORM_NEED[d]);
});
console.log('contrast pairs (cf annotated):', ITEMS.filter(i=>i.cf).length);
const overlap = 2*60 - ITEMS.length;
console.log('minimum overlap between any two 60-item forms:', Math.max(0,overlap), 'items');
console.log('key positions:', pos);
console.log('domain counts:', perD, Object.keys(perD).sort().map(d=>'D'+d+' '+Math.round(perD[d]/ITEMS.length*100)+'%').join(' '));
console.log('task statements covered:', [...new Set(ITEMS.map(i=>i.ts))].sort().join(' '));
console.log('principles used:', [...new Set(ITEMS.map(i=>i.p))].length, 'of', Object.keys(PRINCIPLES).length);
if(problems.length){ console.log('PROBLEMS:'); problems.forEach(p=>console.log('  '+p)); process.exit(1); }

/* --- 12 safe key trims: remove elaboration that is not part of the choice --- */
const TRIMS = {
  q007:[", each with a description explaining when to use it versus its neighbours",""],
  q008:[" (amounts, dates, order numbers, statuses)",""],
  q025:[", rather than always routing through the full pipeline",""],
  q032:[" (searching file contents)",""],
  q047:[", so dismissals can be grouped and analysed by pattern",""],
  q057:[", because the information is absent from the source",""],
  q061:[", each with its own input and output contract",""],
  q073:[", then handle enrichment in follow-up turns",""],
  q083:[", each with its own contract",""],
  q094:[", outside the summarized history",""],
  q098:[", keeping each claim bound to its source URL and title",""],
  q100:[", so agents can see what is available without exploratory calls",""]
};
let trimmed = 0;
ITEMS.forEach(it=>{
  const rule = TRIMS[it.id];
  if(!rule) return;
  it.c.forEach(ci=>{
    if(it.o[ci].indexOf(rule[0]) !== -1){ it.o[ci] = it.o[ci].replace(rule[0], rule[1]); trimmed++; }
  });
});
console.log("safe key trims applied:", trimmed, "of", Object.keys(TRIMS).length);

/* --- British English and AI-tell words, prose only, code spans protected --- */
const SWAP = [
  [/\bnormaliz(e|es|ed|ing|ation)\b/g, (m,s)=>"normalis"+({e:"e",es:"es",ed:"ed",ing:"ing",ation:"ation"})[s]],
  [/\bsummariz(e|es|ed|ing|ation)\b/g, (m,s)=>"summaris"+({e:"e",es:"es",ed:"ed",ing:"ing",ation:"ation"})[s]],
  [/\bprioritiz(e|es|ed|ing)\b/g, (m,s)=>"prioritis"+s],
  [/\borganiz(e|es|ed|ing|ation)\b/g, (m,s)=>"organis"+s],
  [/\brecogniz(e|es|ed|ing)\b/g, (m,s)=>"recognis"+s],
  [/\bcategoriz(e|es|ed|ing|ation)\b/g, (m,s)=>"categoris"+s],
  [/\bgeneraliz(e|es|ed|ing)\b/g, (m,s)=>"generalis"+s],
  [/\bspecializ(e|es|ed|ing|ation)\b/g, (m,s)=>"specialis"+s],
  [/\bminimiz(e|es|ed|ing)\b/g, (m,s)=>"minimis"+s],
  [/\bmaximiz(e|es|ed|ing)\b/g, (m,s)=>"maximis"+s],
  [/\boptimiz(e|es|ed|ing|ation)\b/g, (m,s)=>"optimis"+s],
  [/\bstandardiz(e|es|ed|ing)\b/g, (m,s)=>"standardis"+s],
  [/\bapologiz(e|es|ed|ing)\b/g, (m,s)=>"apologis"+s],
  [/\bbehavior\b/g, "behaviour"], [/\bbehaviors\b/g, "behaviours"], [/\bbehavioral\b/g, "behavioural"],
  [/\bcatalog\b/g, "catalogue"], [/\bcatalogs\b/g, "catalogues"],
  [/\bleverage\b/g, "use"], [/\bleveraging\b/g, "using"],
  [/\bcomprehensive\b/g, "complete"],
  [/\btest center\b/g, "test centre"]
];
function britishise(str){
  if(typeof str !== "string") return str;
  // protect code spans and any snake_case identifier
  const keep = [];
  let s = str.replace(/<code>[\s\S]*?<\/code>|\b[a-z]+(?:_[a-z]+)+\b/g, m=>{
    keep.push(m); return "\u0000" + (keep.length-1) + "\u0000";
  });
  SWAP.forEach(([re, to]) => { s = s.replace(re, to); });
  return s.replace(/\u0000(\d+)\u0000/g, (m,i)=>keep[+i]);
}
let swaps = 0;
const countBefore = JSON.stringify(ITEMS).length;
ITEMS.forEach(it=>{
  if(it.src === "guide") return;   // reproduced verbatim from the exam guide, do not restyle
  ["q","e","cf"].forEach(k=>{ if(it[k]) it[k] = britishise(it[k]); });
  it.o = it.o.map(britishise);
});
Object.keys(PRINCIPLES).forEach(k=>{ PRINCIPLES[k].r = britishise(PRINCIPLES[k].r); PRINCIPLES[k].t = britishise(PRINCIPLES[k].t); });
Object.keys(SCENARIOS).forEach(k=>{ SCENARIOS[k].desc = britishise(SCENARIOS[k].desc); });
Object.keys(TS).forEach(k=>{ TS[k] = britishise(TS[k]); });
console.log("British English pass applied to items, rules, scenarios and task titles");

/* --- new data block --- */
const J = o => JSON.stringify(o, null, 1);
const bank = "<script>\nconst DOMAINS = "+J(DOMAINS)+";\n\nconst SCENARIOS = "+J(SCENARIOS)+
  ";\n\nconst PRINCIPLES = "+J(PRINCIPLES)+";\n\nconst TS = "+J(TS)+";\n\nconst ITEMS = "+J(ITEMS)+";\n<\/script>";

h = h.replace("<script>"+blocks[0]+"<\/script>", bank);
h = h.replace("<script>"+blocks[1]+"<\/script>", fs.readFileSync('engine2.js','utf8').trim());

/* --- CSS additions --- */
h = h.replace("  @media (max-width:640px){", `
  .pill.unsure{color:var(--flag); border-color:var(--flag); font-weight:bold;}
  #pace{font-size:12px; color:var(--muted); white-space:nowrap;}
  #pace.ahead{color:var(--pass);} #pace.behind{color:var(--signal);}
  .nav-btn.unsure-on{border-color:var(--flag); color:var(--flag); font-weight:bold;}
  .pal-btn.unsure{border-style:dashed; border-color:var(--flag);}
  .feedback .prin{border-top:1px solid var(--line); margin-top:12px; padding-top:10px; font-size:13.5px;}
  .feedback .prin b{display:block; font-size:11px; letter-spacing:1.5px; text-transform:uppercase; color:var(--muted); margin-bottom:4px;}
  .feedback .trap{color:#333;}
  .start-links{display:flex; gap:16px; flex-wrap:wrap; align-items:center; margin-top:26px; font-size:14px;}
  .start-links button{border-bottom:2px solid var(--ink); font-weight:bold; padding-bottom:1px;}
  #drill-domains{display:flex; flex-wrap:wrap; gap:8px; margin-top:10px;}
  .prio-card{border:1px solid var(--line); border-left:4px solid var(--signal); border-radius:6px; padding:16px; margin-bottom:14px;}
  .prio-top{display:flex; gap:12px; flex-wrap:wrap; font-size:12px; color:var(--muted); margin-bottom:9px;}
  .prio-count{font-weight:bold; color:var(--signal);}
  .prio-rule{font-size:15px; line-height:1.5;}
  .prio-trap{font-size:13.5px; color:#333; border-top:1px solid var(--line); margin-top:10px; padding-top:9px;}
  .prio-trap b{display:block; font-size:11px; letter-spacing:1.5px; text-transform:uppercase; color:var(--muted); margin-bottom:4px;}
  .rev-mark.uns{color:var(--flag);}
  .risk{border:1px solid var(--signal); border-left:4px solid var(--signal); border-radius:6px; padding:14px 16px; margin:22px 0 6px; font-size:14px;}
  .risk b{display:block; font-size:11px; letter-spacing:1.5px; text-transform:uppercase; color:var(--signal); margin-bottom:5px;}
  #screen-rules{padding:44px 0 80px;}
  .rule-card{border-top:1px solid var(--line); padding:14px 2px;}
  .rule-r{font-size:15px; line-height:1.5;}
  .rule-t{font-size:13.5px; color:#444; margin-top:8px;}
  .rule-t b{font-size:11px; letter-spacing:1.5px; text-transform:uppercase; color:var(--muted); margin-right:8px;}
  @media (max-width:640px){
    #pace{display:none;}`);

const NEW_CSS = `
  .pill.hist{color:var(--signal); border-color:var(--signal); font-weight:bold;}
  #form-grid{display:grid; grid-template-columns:repeat(auto-fill,minmax(150px,1fr)); gap:10px;}
  .form-card{border:1px solid var(--line); border-radius:6px; padding:13px 14px; text-align:left;
             display:flex; flex-direction:column; gap:4px; background:#fff;}
  .form-card:hover{border-color:var(--ink); background:var(--faint);}
  .form-n{font-size:15px; font-weight:bold; line-height:1.2;}
  .form-sub{font-size:11px; color:var(--muted); line-height:1.2;}
  .form-score{font-size:13px; font-variant-numeric:tabular-nums; line-height:1.2;}
  .form-score.pass{color:var(--pass); font-weight:bold;}
  .form-score.fail{color:var(--signal); font-weight:bold;}
  .form-score.none{color:var(--muted); font-size:11px;}
  .custom-row{display:flex; flex-wrap:wrap; align-items:center; gap:12px;}
  .custom-quick{display:flex; gap:6px;}
  .custom-lbl{font-size:13.5px; display:flex; align-items:center; gap:6px;}
  .custom-lbl input[type=number]{width:66px; font-family:inherit; font-size:14px; padding:6px 8px;
             border:1px solid var(--line); border-radius:4px;}
  .custom-lbl input[type=number]:focus{border-color:var(--ink); outline:none;}
  .feedback .contrast{border-left:3px solid var(--flag); padding-left:12px; margin-top:12px;}
  .feedback .contrast b{color:var(--flag);}
  .pill.streak{color:var(--pass); border-color:var(--pass); font-weight:bold;}
  .mastery-grid{display:flex; flex-wrap:wrap; gap:3px; margin-bottom:10px;}
  .mastery-grid i, .mastery-key i{display:inline-block; width:11px; height:11px; border-radius:2px; vertical-align:-1px;}
  .mc-unseen{background:#ececec;}
  .mc-clean{background:var(--pass);}
  .mc-missed{background:#fff; box-shadow:inset 0 0 0 2px var(--signal);}
  .mastery-key{display:flex; flex-wrap:wrap; gap:16px; font-size:12.5px; color:var(--muted); align-items:center;}
  .mastery-key i{margin-right:5px;}
  .rushed{border:1px solid var(--flag); border-left:4px solid var(--flag); border-radius:6px; padding:14px 16px; margin:22px 0 6px; font-size:14px;}
  .rushed b{display:block; font-size:11px; letter-spacing:1.5px; text-transform:uppercase; color:var(--flag); margin-bottom:5px;}
  @media (max-width:520px){
    #form-grid{grid-template-columns:repeat(2,1fr);}
    .custom-row{gap:10px;}
  }
`;
{
  const cssAnchor = "  .hidden{display:none !important;}";
  if(h.indexOf(cssAnchor) === -1) throw new Error("CSS anchor not found");
  h = h.replace(cssAnchor, cssAnchor + "\n" + NEW_CSS.trim() + "\n");
}

/* --- topbar: pace readout --- */
h = h.replace('<span id="tb-spacer"></span>', '<span id="pace" class="hidden"></span>\n      <span id="tb-spacer"></span>');

/* --- item head: unsure pill --- */
h = h.replace('<span class="pill flagged hidden" id="pill-flag">Flagged</span>',
  '<span class="pill flagged hidden" id="pill-flag">Flagged</span>\n      <span class="pill unsure hidden" id="pill-unsure">Marked unsure</span>\n      <span class="pill hist hidden" id="pill-hist"></span>\n      <span class="pill streak hidden" id="pill-streak"></span>');

/* --- navbar: unsure button --- */
h = h.replace('<button class="nav-btn" id="btn-flag" onclick="toggleFlag()">Flag</button>',
  '<button class="nav-btn" id="btn-flag" onclick="toggleFlag()">Flag</button>\n      <button class="nav-btn" id="btn-unsure" onclick="toggleUnsure()">Mark unsure</button>');

/* --- palette legend --- */
h = h.replace('Filled = answered · Dot = flagged for review · Ring = current item',
  'Filled = answered · Dot = flagged · Dashed = marked unsure · Ring = current item');

/* --- start screen: rule sheet + domain drills --- */
h = h.replace('    <div class="note">', `    <div class="start-links">
      <button onclick="openRules('screen-start')">Open the rule sheet</button>
      <span id="rules-count" style="color:var(--muted);font-size:13px;"></span>
    </div>

    <h2 style="font-size:16px;margin:30px 0 4px;">From the official exam guide</h2>
    <div class="guide-box">
      <p class="guide-lead"><span class="guide-tag">Exam guide v1.0 &middot; section 9</span>
        Anthropic publishes <strong><span id="guide-count">12</span> sample questions</strong> in the exam guide itself, to show the format and difficulty of the real thing. They are reproduced here word for word, with their official explanations, and each one is marked as coming from the guide wherever it appears.</p>
      <p class="guide-note">Everything else in this bank is original, written against the guide's task statements. These are the only items that are not.</p>
      <button class="tb-btn primary" onclick="drillGuide()">Practise the guide questions &rarr;</button>
    </div>

    <h2 style="font-size:16px;margin:30px 0 4px;">Your coverage of the bank</h2>
    <div id="mastery"></div>

    <h2 style="font-size:16px;margin:30px 0 4px;">Previous sittings</h2>
    <p style="font-size:13px;color:var(--muted);">Missed items are stored in this browser. Options are reshuffled every time, so answer position is never a clue.</p>
    <div class="start-links" style="margin-top:12px;">
      <button class="tb-btn primary" id="btn-hist-drill" onclick="drillHistory()">Drill what I have missed before</button>
      <button class="tb-btn" onclick="resetHist()">Reset record</button>
      <span id="hist-note" style="font-size:13px;color:var(--muted);"></span>
    </div>

    <h2 style="font-size:16px;margin:30px 0 4px;">Targeted drills</h2>
    <p style="font-size:13px;color:var(--muted);">Untimed. The rule and the trap are shown after each answer.</p>
    <div id="drill-domains"></div>

    <div class="note">`);

/* --- results: score caption id, band wrapper, filters, priority, actions --- */
h = h.replace('<div class="score-cap">Scaled score (100–1,000)</div>',
  '<div class="score-cap" id="res-cap">Scaled score (100–1,000)</div>');
h = h.replace('    <div class="band">', '    <div class="band" id="band-wrap">');
h = h.replace(`      <button class="filter-btn" id="f-wrong" onclick="setFilter('wrong')">Incorrect only</button>`,
  `      <button class="filter-btn" id="f-wrong" onclick="setFilter('wrong')">Incorrect only</button>
      <button class="filter-btn" id="f-unsure" onclick="setFilter('unsure')">Marked unsure</button>`);
h = h.replace('    <h2>Item review</h2>', `    <h2>Priority review</h2>
    <p style="font-size:13px;color:var(--muted);margin-bottom:12px;">Rules behind the items you missed, most-missed first, with the guide sections to re-read.</p>
    <div id="priority"></div>

    <h2>Item review</h2>`);
h = h.replace(`    <div class="again-row">
      <button class="tb-btn primary" onclick="location.reload()">Back to start</button>
    </div>`, `    <div class="again-row">
      <button class="tb-btn primary" id="btn-drill-missed" onclick="drillMissed()">Drill what I missed</button>
      <button class="tb-btn" id="btn-drill-fragile" onclick="drillFragile()">Drill what I was unsure of</button>
      <button class="tb-btn" onclick="drillWeakest()">Drill my weakest domain</button>
      <button class="tb-btn" onclick="openRules('screen-results')">Rule sheet</button>
      <button class="tb-btn" onclick="location.reload()">Back to start</button>
    </div>`);

h = h.replace('    <h2>Item review</h2>', '    <div id="rushed"></div>\n    <div id="risk"></div>\n\n    <h2>Item review</h2>');

/* --- rule sheet screen --- */
h = h.replace('<!-- ================= RESULTS ================= -->', `<div id="screen-rules" class="hidden">
  <div class="wrap">
    <div class="eyebrow">Decision rules</div>
    <h2 style="font-size:26px; line-height:1.2; font-weight:bold; margin-bottom:6px;">The rules this exam tests</h2>
    <div class="sub">Every item in the bank maps to one of these. The trap is the wrong turn that item is built around.</div>
    <div id="rules-body"></div>

    <h2>Explicitly out of scope</h2>
    <p style="font-size:13.5px;color:var(--muted);margin-bottom:10px;">The guide lists these as not tested. Some practice banks include them anyway; a question that turns on one is padding.</p>
    <div class="rule-card"><div class="rule-r">Constitutional AI, RLHF, and safety training methodology · Claude's internal architecture, training, or weights · fine-tuning or training custom models</div></div>
    <div class="rule-card"><div class="rule-r">Deploying or hosting MCP servers: infrastructure, networking, container orchestration, transport layers</div></div>
    <div class="rule-card"><div class="rule-r">Prompt caching implementation detail beyond knowing it exists · token counting and tokenization · rate limits, quotas, and pricing arithmetic</div></div>
    <div class="rule-card"><div class="rule-r">API authentication, OAuth, key rotation, billing and account management · specific cloud provider configuration</div></div>
    <div class="rule-card"><div class="rule-r">Embedding models and vector databases · computer use and browser automation · vision and image analysis · streaming and server-sent events · performance benchmarking and model comparison</div></div>
    <div class="again-row"><button class="tb-btn primary" onclick="closeRules()">Back</button></div>
  </div>
</div>

<!-- ================= RESULTS ================= -->`);

h = h.replace('<h3>Timed exam · full bank</h3>', '<h3>Whole bank, timed</h3>');
h = h.replace('<h3>Exam simulation · 4 of 6 scenarios</h3>', '<h3>Simulation</h3>');
h = h.replace('<h3>Study mode · untimed</h3>', '<h3>Study, untimed</h3>');
h = h.replace('<p>All 60 items in one sitting, 120 minutes, no feedback until you submit. Score report with domain breakdown at the end.</p>', '<p id="m-exam-body"></p>');
h = h.replace('<p>Mirrors the real structure: 4 scenarios drawn at random from the bank of 6. 40 items, 80 minutes.</p>', '<p id="m-sim-body"></p>');
h = h.replace('<p>All 60 items with an answer check and full explanation after each one. Domain shown per item.</p>', '<p id="m-study-body"></p>');
h = h.replace('<span class="go">Start full exam</span>', '<span class="go">Start</span>');
h = h.replace('<span class="go">Start simulation</span>', '<span class="go">Start</span>');
h = h.replace('<span class="go">Start studying</span>', '<span class="go">Start</span>');
h = h.replace('Items are original and written against the task statements in the published exam guide. They are not actual exam content. Scaled scoring here is a linear approximation of the 100 to 1,000 scale; the real exam equates scores across forms. Nothing is saved between page loads.',
  'Most items are original, written against the task statements in the published exam guide. Twelve are the sample questions the guide itself publishes in section 9, reproduced with attribution. None of it is secure exam content. Scaled scores here approximate the real 100 to 1,000 scale, which is equated across forms. Your results and missed items are stored in this browser only.');

h = h.replace('    <div class="modes">', `    <h2 style="font-size:16px;margin:4px 0 2px;">10 practice tests</h2>
    <p style="font-size:13px;color:var(--muted);margin-bottom:12px;">Each test is a fixed 60-item form built to the blueprint weights (16/11/12/12/9), timed at 120 minutes. Options are reshuffled on every attempt. Your best score per test is stored in this browser.</p>
    <p id="form-note" style="font-size:13px;color:var(--muted);margin-bottom:12px;"></p>
    <div id="form-grid"></div>

    <h2 style="font-size:16px;margin:30px 0 2px;">Custom length</h2>
    <p style="font-size:13px;color:var(--muted);margin-bottom:12px;">Any length, built to the same weights. Timed runs allow 2 minutes per item. Each run continues from where the last one stopped in the bank, so consecutive runs draw different items.</p>
    <div class="custom-row">
      <span class="custom-quick">
        <button class="filter-btn" onclick="setCustom(10)">10</button>
        <button class="filter-btn" onclick="setCustom(20)">20</button>
        <button class="filter-btn" onclick="setCustom(30)">30</button>
        <button class="filter-btn" onclick="setCustom(45)">45</button>
      </span>
      <label class="custom-lbl">or <input type="number" id="custom-n" value="25" min="5" step="1"> items</label>
      <label class="custom-lbl"><input type="checkbox" id="custom-untimed"> untimed, show answers as I go</label>
      <button class="tb-btn primary" onclick="startCustom()">Start</button>
    </div>

    <h2 style="font-size:16px;margin:30px 0 2px;">Other modes</h2>
    <div class="modes">`);

/* --- start screen copy --- */
h = h.replace('60 original scenario-based items covering the full six-scenario bank.',
  ITEMS.length + ' original items covering all six scenarios and all 30 task statements.');
h = h.replace('<tr><td>Item bank</td><td>60 items, 10 per scenario, across all 6 exam scenarios</td></tr>',
  '<tr><td>Item bank</td><td>' + ITEMS.length + ' items across 6 scenarios and all 30 task statements. ' +
  ITEMS.filter(i=>i.cf).length + ' are contrast pairs: near-identical setups where one detail changes the answer.</td></tr>');
h = h.replace('<tr><td>Passing score</td><td>Scaled score of 720 on a 100 to 1,000 scale (about 69% correct)</td></tr>',
  '<tr><td>Passing score</td><td>720 on a 100 to 1,000 scale. Scored by blueprint weight rather than raw item count, so a weak high-weight domain costs what it would on the real exam.</td></tr>');

{
  const pa = "  @media (prefers-reduced-motion: reduce){ *{transition:none !important;} }";
  if(h.indexOf(pa) === -1) throw new Error("print CSS anchor not found");
  h = h.replace(pa, pa + `
  @media print{
    #topbar, #navbar, #palette, .again-row, .start-links, .filters, .modes,
    #drill-domains, #form-grid, .custom-row, #mastery{display:none !important;}
    body{font-size:11pt; color:#000;}
    .wrap{max-width:none; padding:0;}
    .rule-card, .prio-card, .rev-card{break-inside:avoid; page-break-inside:avoid;}
    h1, h2{break-after:avoid; page-break-after:avoid;}
  }`);
}

/* --- Whetstone shell: exam picker above the CCAR-F app --- */
{
  const startAnchor = '<div id="screen-start">';
  if(h.indexOf(startAnchor) === -1) throw new Error("start screen anchor not found");
  h = h.replace(startAnchor, `<div id="screen-home">
  <div class="wrap">
    <nav class="a2a-home-nav" aria-label="Architecture to Autonomy">
      <a class="a2a-home-link" href="../../../"><span class="a2a-home-ico" aria-hidden="true">&#8592;</span> Architecture to Autonomy</a>
      <a class="a2a-home-link ghost" href="../../../#apps">All apps</a>
    </nav>
    <img id="hero" alt="Whetstone. Practice exams for AI certifications." src="__HERO__">
    <h1 class="sr-only">Whetstone: practice exams for AI certifications</h1>
    <div class="sub">Made for practice and exam preparation. Mostly original items written from published exam guides, plus the sample questions those guides publish, shown with attribution. Not affiliated with any certification body, and no secure exam content.</div>
    <div id="exam-grid"></div>
  </div>
</div>

<div id="screen-start" class="hidden">`);

  // the start screen gets a way back to the picker
  h = h.replace('<div class="eyebrow">Practice examination · Exam code CCAR-F</div>',
    '<button class="back-link" onclick="goHome()">Back to all exams</button>\n    <div class="eyebrow">Practice examination · Exam code CCAR-F</div>');

  h = h.replace('<title>CCAR-F Practice Exam · Claude Certified Architect – Foundations</title>',
    '<title>Whetstone · Practice exams for AI certifications</title>');
  h = h.replace('<span id="tb-title">CCAR-F Practice</span>', '<span id="tb-title">Whetstone · CCAR-F</span>');
}

/* --- A2A blog palette, applied as an override layer --- */
{
  const styleEnd = "</style>";
  if(h.indexOf(styleEnd) === -1) throw new Error("style block not found");
  const A2A = `
  /* ===== Whetstone picker ===== */
  #screen-home{padding:40px 0 80px;}
  #hero{display:block; width:100%; height:auto; border:1px solid var(--line);
        border-radius:14px; box-shadow:0 8px 26px rgba(15,23,42,0.08); margin-bottom:22px;}
  .sr-only{position:absolute; width:1px; height:1px; padding:0; margin:-1px; overflow:hidden;
           clip:rect(0 0 0 0); white-space:nowrap; border:0;}
  #exam-grid{display:block; margin:24px 0 8px;}
  .prog{margin:0 0 34px;}
  .prog-head{display:flex; align-items:center; gap:16px; margin-bottom:14px;}
  .prog-rule{flex:1 1 auto; height:1px; background:rgba(148,163,184,0.38);}
  .prog-count{font-family:"IBM Plex Mono","Courier New",monospace; font-size:11px;
              letter-spacing:1.6px; text-transform:uppercase; color:var(--muted); white-space:nowrap;}
  .exam-card{border:1px solid var(--line); border-radius:14px; padding:20px; text-align:left;
             display:flex; flex-direction:column; gap:8px; background:var(--card);
             box-shadow:0 6px 20px rgba(15,23,42,0.06);}
  .exam-card.live:hover{border-color:rgba(15,118,110,0.55); background:#fff;
             box-shadow:0 10px 28px rgba(15,23,42,0.10);}
  .exam-card.soon{background:rgba(255,255,255,0.55); border-style:dashed; box-shadow:none; cursor:default;}
  .exam-code{font-family:"IBM Plex Mono","Courier New",monospace; font-size:11px; letter-spacing:1.6px;
             color:var(--teal); text-transform:uppercase;}
  .exam-card.soon .exam-code{color:var(--muted);}
  .exam-name{font-size:16px; font-weight:bold; line-height:1.25;}
  .exam-who{font-size:13px; color:var(--muted); line-height:1.45;}
  .exam-status{margin-top:auto; padding-top:10px; font-size:12.5px; display:flex; align-items:center; gap:8px;}
  .exam-status .dot{width:8px; height:8px; border-radius:50%; background:var(--teal); flex:0 0 8px;}
  .exam-card.soon .exam-status .dot{background:#cbd5e1;}
  .exam-status .txt{color:var(--teal); font-weight:bold;}
  .exam-card.soon .exam-status .txt{color:var(--muted); font-weight:normal;}
  .prog-label{font-family:"IBM Plex Mono","Courier New",monospace; font-size:11px; letter-spacing:1.6px;
             text-transform:uppercase; color:var(--teal); white-space:nowrap;}
  .prog-grid{display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:14px;}
  .prog-note{font-size:12.5px; color:var(--muted); margin:16px 0 0; line-height:1.55; max-width:none;}
  @media (max-width:560px){
    .prog-head{flex-wrap:wrap; gap:10px;}
    .prog-rule{order:3; flex-basis:100%;}
  }
  /* Home tab: return to the Architecture to Autonomy site */
  .a2a-home-nav{display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-bottom:26px;}
  .a2a-home-link{display:inline-flex; align-items:center; gap:8px; font-size:13px; font-weight:600; text-decoration:none;
    color:#0f766e; border:1px solid rgba(15,118,110,0.30); background:rgba(15,118,110,0.06);
    border-radius:999px; padding:7px 15px; transition:background .15s, border-color .15s;}
  .a2a-home-link:hover{background:rgba(15,118,110,0.12); border-color:rgba(15,118,110,0.55);}
  .a2a-home-link.ghost{color:var(--muted); background:transparent; border-color:var(--line);}
  .a2a-home-link.ghost:hover{color:#0f766e; border-color:rgba(15,118,110,0.40);}
  .a2a-home-ico{font-size:15px; line-height:1;}

  /* Exam card: status badge, mono metadata, explicit call to action */
  .exam-card.live{border-left:3px solid var(--teal);}
  .exam-top{display:flex; align-items:center; justify-content:space-between; gap:8px;}
  .exam-badge{font-family:"IBM Plex Mono","Courier New",monospace; font-size:9.5px; letter-spacing:1.2px;
    text-transform:uppercase; padding:3px 7px; border-radius:3px; white-space:nowrap; flex:0 0 auto;}
  .exam-badge.free{background:var(--teal); color:#fff;}
  .exam-badge.soon{border:1px solid var(--line); color:var(--muted);}
  .exam-status{margin-top:auto; padding-top:12px; display:flex; flex-direction:column;
    align-items:flex-start; gap:3px;}
  .exam-meta{font-family:"IBM Plex Mono","Courier New",monospace; font-size:10.5px; letter-spacing:0.6px;
    text-transform:uppercase; color:var(--muted); font-variant-numeric:tabular-nums;}
  .exam-cta{margin-top:7px; font-size:13px; font-weight:bold; color:var(--teal);}
  .exam-card.live:hover .exam-cta{text-decoration:underline;}
  #timer{font-variant-numeric:tabular-nums;}

  /* The official exam-guide sample questions, called out on their own */
  .guide-box{border:1px solid rgba(234,88,12,0.30); border-left:3px solid var(--orange);
    background:rgba(234,88,12,0.05); border-radius:12px; padding:14px 16px; margin-top:6px;}
  .guide-tag{display:inline-block; font-family:"IBM Plex Mono","Courier New",monospace;
    font-size:9.5px; letter-spacing:1.2px; text-transform:uppercase; padding:3px 7px;
    border-radius:3px; background:var(--orange); color:#fff; margin-right:8px; vertical-align:1px;}
  .guide-lead{font-size:13.5px; line-height:1.6; margin:0 0 8px;}
  .guide-note{font-size:12.5px; color:var(--muted); line-height:1.55; margin:0 0 12px;}
  .pill.guide{background:rgba(234,88,12,0.10); border-color:rgba(234,88,12,0.45);
    color:var(--orange-ink); font-weight:bold;}

  /* Navigator grid: answered reads as an outline, the current item is filled */
  .pal-btn{font-variant-numeric:tabular-nums;}
  .pal-btn.answered{background:#fff; border-color:var(--teal); color:var(--teal); font-weight:bold;}
  .pal-btn.current, .pal-btn.answered.current{background:var(--orange); border-color:var(--orange);
    color:#fff; box-shadow:none; font-weight:bold;}
  .pal-btn.flagged::after{content:""; position:absolute; top:3px; right:3px; width:5px; height:5px;
    border-radius:50%; background:var(--flag);}

  .back-link{font-size:13px; color:var(--teal); border-bottom:1px solid rgba(15,118,110,0.4);
             padding-bottom:1px; margin-bottom:18px; display:inline-block;}
  .back-link:hover{color:#0b5d57;}

  /* ===== Architecture to Autonomy palette ===== */
  :root{
    --ink:#0f172a; --muted:#475569; --meta:#334155;
    --line:rgba(148,163,184,0.34); --faint:rgba(15,23,42,0.045);
    --teal:#0f766e; --orange:#ea580c;
    --pass:#0f766e;          /* teal reads positive and is the A2A accent */
    --signal:#CC092F;        /* unchanged: signal only */
    --flag:#ea580c;          /* A2A orange: borders and accents */
    --orange-ink:#c2410c;    /* darkened for text, 5.2:1 on card */
    --card:rgba(255,255,255,0.94);
  }
  html,body{
    font-family:"Space Grotesk", Arial, Helvetica, sans-serif;
    color:var(--ink);
    background:
      radial-gradient(900px 500px at 8% -20%, rgba(15,118,110,0.12), transparent 60%),
      radial-gradient(850px 420px at 100% -10%, rgba(234,88,12,0.12), transparent 55%),
      linear-gradient(#f3f6fb, #eef2f7);
    background-attachment:fixed;
  }
  code{background:rgba(15,118,110,0.08); color:#0b5d57; border:1px solid rgba(15,118,110,0.18);}

  /* kicker */
  .eyebrow{
    display:inline-block; font-family:"IBM Plex Mono", "Courier New", monospace;
    font-size:11px; letter-spacing:1.8px; color:var(--teal);
    background:rgba(15,118,110,0.08); border:1px solid rgba(15,118,110,0.45);
    border-radius:999px; padding:5px 12px;
  }
  h1 em, h1 i{color:var(--orange); font-style:normal;}


  /* surfaces */
  #topbar{background:rgba(243,246,251,0.9); backdrop-filter:blur(8px);
          border-bottom:1px solid rgba(148,163,184,0.25);}
  #navbar{background:rgba(243,246,251,0.94); backdrop-filter:blur(8px);
          border-top:1px solid rgba(148,163,184,0.25);}
  .facts td{border-top-color:var(--line);}
  .mode-card, .form-card, .scen, .opt, .feedback, .rev-card, .prio-card,
  .rule-card, #palette .panel, .risk, .rushed{
    background:var(--card);
  }
  .mode-card, .form-card{
    border:1px solid var(--line); border-radius:14px;
    box-shadow:0 6px 20px rgba(15,23,42,0.06);
  }
  .mode-card:hover, .form-card:hover{
    border-color:rgba(15,118,110,0.5); background:#fff;
    box-shadow:0 10px 28px rgba(15,23,42,0.10);
  }
  .mode-card .go{border-bottom-color:var(--teal); color:var(--teal);}
  .scen{border:1px solid var(--line); border-left:4px solid var(--teal); border-radius:12px;}
  .opt{border-radius:12px;}
  .opt:hover{border-color:rgba(15,118,110,0.55);}
  .opt.selected{border-color:var(--teal); background:rgba(15,118,110,0.06);
                box-shadow:inset 0 0 0 1px var(--teal);}
  .opt.selected .letter{background:var(--teal); border-color:var(--teal);}
  .opt .letter{border-color:rgba(15,23,42,0.55);}
  .opt.correct{background:rgba(15,118,110,0.07);}
  .opt.wrongpick{background:rgba(204,9,47,0.05);}
  .feedback, .rev-card, .prio-card{border-radius:14px; border-color:var(--line);}
  .rev-opt.is-correct{background:rgba(15,118,110,0.08); color:#0b5d57;}
  .rev-opt.is-wrongpick{background:rgba(204,9,47,0.06); color:#8f0a23;}
  .prio-card{border-left:4px solid var(--orange);}
  .feedback .prin{border-top-color:var(--line);}

  /* pills and controls */
  .pill, .filter-btn, .tb-btn, .nav-btn, .check-btn, .custom-lbl input[type=number]{
    border-radius:999px;
  }
  .tb-btn, .nav-btn, .filter-btn{border-color:rgba(51,65,85,0.22); background:rgba(255,255,255,0.82);}
  .tb-btn:hover, .nav-btn:hover, .filter-btn:hover{background:#fff; border-color:var(--teal);}
  .tb-btn.primary, .filter-btn.on, .nav-btn.submit, .check-btn{
    background:var(--teal); border-color:var(--teal); color:#fff;
  }
  .tb-btn.primary:hover, .nav-btn.submit:hover{background:#0b5d57; border-color:#0b5d57;}
  .pill.dom{background:rgba(15,118,110,0.08); color:#0b5d57;}
  .pill.two{border-color:var(--teal); color:var(--teal);}
  .verdict-badge{border-radius:999px;}
  .band-track{background:rgba(15,23,42,0.06); border-color:var(--line);}
  .dt-fill{background:var(--teal);}
  .dt-bar{background:rgba(15,23,42,0.06);}
  .domrow .bar{background:var(--teal);}
  .pal-btn{border-radius:8px;}
  .pal-btn.answered{background:#fff; border-color:var(--teal); color:var(--teal); font-weight:bold;}
  .pal-btn.current, .pal-btn.answered.current{background:var(--orange); border-color:var(--orange); color:#fff; box-shadow:none;}
  .mc-unseen{background:rgba(15,23,42,0.09);}
  .mc-clean{background:var(--teal);}
  .rule-card{border-top-color:var(--line);}
  .rule-t b{color:var(--teal);}
  .feedback .prin b, .rev-exp b{color:var(--teal);}
  .feedback .trap b, .feedback .contrast b, .rushed b{color:var(--orange-ink);}
  .prio-trap b, .prio-count{color:var(--orange-ink);}
  .pill.unsure, .nav-btn.unsure-on, .rev-mark.uns{color:var(--orange-ink);}
  #timer{border-color:var(--line); background:rgba(255,255,255,0.7);}
  `;
  h = h.replace(styleEnd, A2A + "\n" + styleEnd);
}

{
  const heroPath = 'card-64.png';
  if(!fs.existsSync(heroPath)) throw new Error('hero image missing: ' + heroPath);
  const b64 = fs.readFileSync(heroPath).toString('base64');
  if(h.indexOf('__HERO__') === -1) throw new Error('hero placeholder not found');
  h = h.replace('__HERO__', 'data:image/png;base64,' + b64);
  console.log('hero inlined:', Math.round(b64.length/1024) + 'KB base64');
}

const REQUIRED = [
  'Made for practice and exam preparation',
  '.prog{', '.prog-head{', '.prog-rule{', '.prog-count{', '#exam-grid{display:block',
  'id="hero"', '.sr-only{', 'data:image/png;base64,',
  'id="form-note"',
  '.prog-label{', '.prog-grid{', '.prog-note{', 'Practice exams for AI certifications',
  'id="screen-home"', 'id="exam-grid"', '.exam-card{', '.exam-card.soon{', '.back-link{', 'Whetstone',
  '--orange-ink:#c2410c',
  'Architecture to Autonomy palette', '--teal:#0f766e', '--orange:#ea580c', 'Space Grotesk',
  '@media print{',
  'id="mastery"', 'id="rushed"', 'id="pill-streak"', '.mastery-grid{', '.mc-clean{', '.rushed{', '.pill.streak{',
  'id="m-exam-body"', 'id="m-sim-body"', 'id="m-study-body"', 'id="rules-count"',
  'stored in this browser only',
  "#form-grid{", ".form-card{", ".form-n{", ".form-score{", ".form-score.pass{",
  ".custom-row{", ".custom-lbl input[type=number]{", ".pill.hist{", ".feedback .contrast{",
  ".prio-card{", ".risk{", ".rule-card{", ".pill.unsure{",
  'id="form-grid"', 'id="custom-n"', 'id="custom-untimed"', 'id="risk"',
  'id="rules-body"', 'id="pill-hist"', 'id="btn-hist-drill"', 'id="priority"'
];
const missing = REQUIRED.filter(sel => h.indexOf(sel) === -1);
if(missing.length){
  console.log("BUILD FAILED - these never landed in the output:");
  missing.forEach(m => console.log("  " + m));
  process.exit(1);
}
console.log("all " + REQUIRED.length + " required styles and elements present");
/* --- post-build steps, previously run by hand --- */
{
  // the custom-length input's ceiling is the bank size
  const before = h;
  h = h.replace('value="25" min="5"', 'value="25" min="5" max="' + ITEMS.length + '"');
  if(h === before) throw new Error('custom-length input not found');

  // the mark doubles as an inline favicon so the file stays self-contained
  const markPath = 'whetstone-mark.svg';
  if(!fs.existsSync(markPath)) throw new Error('mark missing: ' + markPath);
  const mark = fs.readFileSync(markPath, 'utf8')
    .replace(/\n/g, '').replace(/"/g, '%22').replace(/#/g, '%23')
    .replace(/</g, '%3C').replace(/>/g, '%3E');
  h = h.replace('</title>', '</title>\n<link rel="icon" href="data:image/svg+xml,' + mark + '">');
  if(h.indexOf('rel="icon"') === -1) throw new Error('favicon not injected');
  console.log('post-build: max=' + ITEMS.length + ' set, favicon inlined');
}

fs.writeFileSync('whetstone.html', h);
console.log('wrote whetstone.html (' + Math.round(h.length/1024) + 'KB)');
console.log('written:', h.length, 'bytes');
